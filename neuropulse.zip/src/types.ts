export type RiskLevel = 'Low' | 'Moderate' | 'Elevated';
export type ViewMode = 'patient' | 'clinical' | 'research';
export type AppMode = ViewMode;
export type AppSection = 'overview' | 'brain' | 'eeg' | 'prediction' | 'models' | 'history' | 'reports' | 'settings';

export interface BrainRegionActivity {
  id: string;
  name: string;
  activityScore: number; // 0 to 1
  riskContribution: number; // 0 to 1
  associatedChannels: string[];
  dominantBands: string[];
  description: string;
  coords: [number, number, number]; // 3D position
}

export interface Electrode {
  id: string;
  name: string;
  fullName: string;
  coords: [number, number, number]; // Scalp 3D coordinate
  regionId: string;
  activityScore: number;
  riskContribution: number;
  dominantBand: string;
  impedanceKohm: number;
  signalQuality: number; // 0 to 100
}

export interface EEGChannel {
  id: string;
  label: string;
  region: string;
  dominantBand: string;
  rmsAmplitude: number; // in µV
  status: 'normal' | 'elevated' | 'critical';
  samples: number[]; // eeg voltage trace
}

export interface EEGWindow {
  startTimeSec: number;
  durationSec: number;
  samplingRateHz: number;
  channels: EEGChannel[];
  timePoints: number[];
}

export interface FrequencyBand {
  name: 'Delta' | 'Theta' | 'Alpha' | 'Beta' | 'Gamma';
  range: string;
  absolutePower: number; // µV²/Hz
  relativePower: number; // 0 to 100 %
  baselineDeltaPercent: number; // e.g. +31%
  description: string;
}

export interface FeatureContribution {
  id: string;
  feature: string;
  category: 'spectral' | 'connectivity' | 'temporal' | 'complexity';
  impact: number; // signed impact on log-odds or raw score
  percentage: number; // formatted contribution, e.g. +24%
  direction: 'increase' | 'decrease';
  value: string;
  description: string;
}

export interface PredictionTimelineEvent {
  timeSec: number;
  timeLabel: string;
  riskScore: number;
  phase: 'INTERICTAL' | 'PREICTAL' | 'MODEL_ALERT' | 'SEIZURE_WINDOW';
  note?: string;
}

export interface Prediction {
  timestamp: string;
  riskScore: number; // 0 to 100
  riskLevel: RiskLevel;
  predictionHorizon: string; // e.g. "10–30 min"
  horizonMinutesMin: number;
  horizonMinutesMax: number;
  estimatedRegion: string;
  associatedChannels: string[];
  modelName: string;
  modelVersion: string;
  confidenceInterval: [number, number];
  signalQualityScore: number;
  topFeatures: FeatureContribution[];
  timeline: PredictionTimelineEvent[];
  currentTimeOffsetSec: number;
}

export interface PatientRecording {
  id: string;
  code: string;
  date: string;
  duration: string;
  sampleRate: number;
  channelCount: number;
  qualityScore: number;
  alertTriggered: boolean;
  status: 'completed' | 'live_streaming' | 'archived';
}

export interface Patient {
  id: string;
  code: string;
  alias: string;
  name?: string;
  age: number;
  gender: string;
  diagnosis: string;
  seizureType: string;
  monitoringDurationHours: number;
  baselineAlphaHz: number;
  impedanceAverage: number;
  recordings: PatientRecording[];
}

export interface PatientHistoryEvent {
  id: string;
  patientId: string;
  date: string;
  recordingId: string;
  peakRisk: number;
  predictionLeadMin: number;
  associatedChannels: string[];
  estimatedRegion: string;
  model: string;
  outcome: 'Validated Preictal Pattern' | 'Preventative Protocol Triggered' | 'Transient Physiological Burst' | 'Subclinical Spike Discharge';
  verifiedByPhysician: boolean;
  notes: string;
}

export interface ModelMetrics {
  id: string;
  name: string;
  architecture: string;
  f1: number | null;
  recall: number | null;
  specificity: number | null;
  aucRoc: number | null;
  falseAlarmRate24h: number | null;
  meanLeadTimeMin: number | null;
  parameters: string;
  status: 'production' | 'benchmark' | 'training';
  isCurrentActive: boolean;
}

export interface ConnectivityNode {
  id: string;
  label: string;
  x: number;
  y: number;
  region: string;
}

export interface ConnectivityEdge {
  source: string;
  target: string;
  weight: number; // 0 to 1
  metric: 'correlation' | 'coherence' | 'phase_locking';
}

export interface SystemReport {
  id: string;
  patientId: string;
  recordingId: string;
  generatedAt: string;
  institution: string;
  primaryInvestigator: string;
  signalQuality: number;
  recordingDuration: string;
  predictionSummary: {
    peakRisk: number;
    riskCategory: RiskLevel;
    predictionHorizon: string;
    estimatedRegion: string;
    associatedChannels: string[];
  };
  dominantFeatures: {
    feature: string;
    contribution: string;
    baselineShift: string;
  }[];
  limitationsDisclaimer: string;
}
