import React from 'react';
import { Prediction } from '@/src/types';
import { Gauge, ShieldAlert, Cpu, Info, CheckCircle2 } from 'lucide-react';

interface RiskGaugeProps {
  prediction: Prediction;
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({ prediction }) => {
  const score = prediction.riskScore;
  const isElevated = score >= 65;
  const isModerate = score >= 35 && score < 65;

  // Arc calculation for semi-circular scientific speedometer
  const radius = 70;
  const strokeWidth = 10;
  const circumference = Math.PI * radius; // Half circle
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-4 backdrop-blur-md flex flex-col justify-between">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5 mb-2">
        <h4 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wide flex items-center gap-1.5">
          <Gauge className="w-3.5 h-3.5 text-cyan-400" />
          ML Risk Gauge
        </h4>
        <span className="text-[10px] text-slate-400 font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800">
          Supervised Ensemble
        </span>
      </div>

      {/* Center Semi-Circle Gauge SVG */}
      <div className="flex flex-col items-center justify-center my-1 relative">
        <svg className="w-48 h-28 overflow-visible" viewBox="0 0 160 90">
          <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="50%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#f43f5e" />
            </linearGradient>
          </defs>

          {/* Background Arc */}
          <path
            d="M 10 85 A 70 70 0 0 1 150 85"
            fill="none"
            stroke="#1e293b"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />

          {/* Value Indicator Arc */}
          <path
            d="M 10 85 A 70 70 0 0 1 150 85"
            fill="none"
            stroke="url(#gaugeGradient)"
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />

          {/* Threshold marker pins at 35% and 65% */}
          <circle cx="48" cy="30" r="2" fill="#64748b" />
          <circle cx="112" cy="30" r="2" fill="#64748b" />
        </svg>

        {/* Center Big Value */}
        <div className="absolute top-12 flex flex-col items-center">
          <span className={`text-4xl font-extrabold font-mono tracking-tight ${
            isElevated ? 'text-rose-400' : isModerate ? 'text-amber-400' : 'text-cyan-400'
          }`}>
            {score}%
          </span>
          <span className={`text-[11px] font-bold font-mono uppercase tracking-widest px-2 py-0.5 rounded ${
            isElevated ? 'bg-rose-500/20 text-rose-300' : isModerate ? 'bg-amber-500/20 text-amber-300' : 'bg-cyan-500/20 text-cyan-300'
          }`}>
            {prediction.riskLevel}
          </span>
        </div>

        {/* Scale labels */}
        <div className="flex justify-between w-48 text-[10px] font-mono text-slate-400 px-2 mt-1">
          <span>Low (0%)</span>
          <span className="text-slate-500">Mod (35%)</span>
          <span className="text-slate-500">Elevated (65%)</span>
          <span>100%</span>
        </div>
      </div>

      {/* Telemetry metadata */}
      <div className="space-y-1.5 mt-3 pt-3 border-t border-slate-800/80 text-xs font-mono">
        <div className="flex justify-between text-slate-300">
          <span className="text-slate-400">ML Risk Score</span>
          <span className="font-bold text-slate-100">{score}%</span>
        </div>
        <div className="flex justify-between text-slate-300">
          <span className="text-slate-400">Prediction Horizon</span>
          <span className="text-cyan-300 font-semibold">{prediction.predictionHorizon}</span>
        </div>
        <div className="flex justify-between text-slate-300">
          <span className="text-slate-400">Model Architecture</span>
          <span className="text-slate-200">XGBoost + Wavelet</span>
        </div>
        <div className="flex justify-between text-slate-300">
          <span className="text-slate-400">Model Version</span>
          <span className="text-slate-400">v1.4-rc2</span>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="mt-3 p-2 bg-slate-900/60 rounded border border-slate-800 text-[10px] text-slate-400 leading-tight">
        Experimental preictal susceptibility estimate. Not a calibrated absolute clinical probability.
      </div>
    </div>
  );
};
