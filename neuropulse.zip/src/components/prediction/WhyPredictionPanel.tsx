import React, { useState } from 'react';
import { FeatureContribution } from '@/src/types';
import { HelpCircle, Info, Sparkles, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface WhyPredictionPanelProps {
  features: FeatureContribution[];
  selectedChannelId?: string;
}

export const WhyPredictionPanel: React.FC<WhyPredictionPanelProps> = ({
  features,
  selectedChannelId = 'T3',
}) => {
  const [showTooltip, setShowTooltip] = useState<boolean>(false);
  const [expandedFeatureId, setExpandedFeatureId] = useState<string | null>(null);

  return (
    <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-4 backdrop-blur-md">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <h3 className="text-xs font-bold text-slate-100 font-mono tracking-wide uppercase flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            Why did the model predict elevated risk?
          </h3>
        </div>

        {/* SHAP / Scientific Causation Information Tooltip Button */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowTooltip(!showTooltip)}
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            className="flex items-center gap-1 text-[11px] font-mono text-cyan-400 hover:text-cyan-300 bg-cyan-950/40 border border-cyan-800/50 px-2 py-0.5 rounded transition-colors"
          >
            <HelpCircle className="w-3 h-3" />
            <span>SHAP Attribution Note</span>
          </button>

          {showTooltip && (
            <div className="absolute right-0 top-7 z-30 w-80 p-3 bg-slate-900 border border-cyan-500/40 rounded-lg shadow-2xl text-[11px] text-slate-300 leading-relaxed font-sans">
              <div className="flex items-start gap-2 mb-1.5">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span className="font-semibold text-slate-100 font-mono">Scientific Disclaimer</span>
              </div>
              <p>
                Feature contributions are computed using TreeSHAP / Integrated Gradients. They indicate statistical feature importance in shifting the model risk output from baseline, and <strong>do not imply medical causation or direct biological etiology</strong>.
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 mb-3">
        <p className="text-[11px] text-slate-400 font-mono">
          These features contributed most strongly to this model output:
        </p>
        {selectedChannelId && (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 text-cyan-300 font-bold shrink-0">
            Lead: {selectedChannelId}
          </span>
        )}
      </div>

      {/* Feature Contributions SHAP Bars */}
      <div className="space-y-2.5">
        {features.map((feat) => {
          const isExpanded = expandedFeatureId === feat.id;
          const isPositive = feat.percentage > 0;
          const isLeadRelevant = selectedChannelId ? feat.description.includes(selectedChannelId) || (selectedChannelId.startsWith('T') && feat.category === 'spectral') : false;

          return (
            <div
              key={feat.id}
              onClick={() => setExpandedFeatureId(isExpanded ? null : feat.id)}
              className={`p-2.5 rounded-lg border transition-all cursor-pointer ${
                isExpanded
                  ? 'bg-slate-900/90 border-cyan-500/50'
                  : isLeadRelevant
                  ? 'bg-cyan-950/20 border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                  : 'bg-slate-900/50 border-slate-800/70 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-mono mb-1.5">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  {feat.feature}
                </span>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400">{feat.value}</span>
                  <span
                    className={`font-mono font-bold text-xs px-1.5 py-0.5 rounded ${
                      isPositive
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    }`}
                  >
                    {isPositive ? `+${feat.percentage}%` : `${feat.percentage}%`}
                  </span>
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-500" />}
                </div>
              </div>

              {/* Visual SHAP horizontal contribution bar */}
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex items-center">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    feat.percentage >= 20
                      ? 'bg-gradient-to-r from-rose-500 to-amber-400'
                      : feat.percentage >= 12
                      ? 'bg-gradient-to-r from-amber-400 to-cyan-400'
                      : 'bg-cyan-400'
                  }`}
                  style={{ width: `${Math.min(feat.percentage * 3.5, 100)}%` }}
                />
              </div>

              {isExpanded && (
                <div className="mt-2 pt-2 border-t border-slate-800 text-[11px] text-slate-300 font-sans leading-relaxed">
                  <p>{feat.description}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-[10px] font-mono text-slate-500">
                    <span>Feature Category: <strong className="text-slate-400 capitalize">{feat.category}</strong></span>
                    <span>Raw Impact: <strong className="text-slate-400">+{feat.impact}</strong></span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-3 text-[10px] font-mono text-slate-500 flex items-center justify-between">
        <span>Attribution Method: TreeSHAP (Lundberg et al.)</span>
        <span>Lead Correlation: T3 / T5 Ipsilateral</span>
      </div>
    </div>
  );
};
