import React from 'react';
import { Prediction } from '@/src/types';
import { Clock, AlertTriangle, ShieldCheck, BellRing, Sparkles } from 'lucide-react';

interface PredictionTimelineProps {
  prediction: Prediction;
  className?: string;
}

export const PredictionTimeline: React.FC<PredictionTimelineProps> = ({
  prediction,
  className = '',
}) => {
  const isAlertActive = prediction.riskScore >= 65;

  return (
    <div className={`bg-[#0d121d] border border-slate-800 rounded-xl p-4 backdrop-blur-md ${className}`}>
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3 mb-4">
        <div>
          <h4 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wide flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            EEG Temporal Progression & Prediction Horizon Timeline
          </h4>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Phase mapping relative to electrographic pattern evolution and statistical horizon.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isAlertActive ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-rose-500/20 border border-rose-500/40 text-rose-300 font-mono text-xs font-semibold animate-pulse">
              <BellRing className="w-3.5 h-3.5" />
              <span>PREICTAL ALERT STATE</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>INTERICTAL STABLE</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Visual Phase Timeline Bar */}
      <div className="relative pt-6 pb-12">
        {/* Phase Bands Bar */}
        <div className="relative h-9 w-full bg-slate-900 rounded-lg overflow-hidden border border-slate-800 flex">
          {/* 1. PAST: INTERICTAL (0% to 45%) */}
          <div
            className="h-full bg-slate-800/80 border-r border-slate-700/60 flex items-center justify-center relative group"
            style={{ width: '45%' }}
            title="Interictal resting physiological baseline"
          >
            <span className="text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wider">
              INTERICTAL
            </span>
          </div>

          {/* 2. PAST -> PRESENT: PREICTAL DRIFT (45% to 60%) */}
          <div
            className="h-full bg-gradient-to-r from-slate-800 to-amber-950/80 border-r border-amber-700/60 flex items-center justify-center relative"
            style={{ width: '15%' }}
            title="Preictal drift with emergent theta slowing and synchrony"
          >
            <span className="text-[10px] font-mono text-amber-300 font-bold uppercase tracking-wider">
              PREICTAL
            </span>
          </div>

          {/* 3. FUTURE HORIZON: PREDICTION HORIZON (60% to 85%) */}
          <div
            className="h-full bg-gradient-to-r from-rose-950/90 to-rose-900/60 border-r border-rose-600/60 flex items-center justify-center relative"
            style={{ width: '25%' }}
            title="Model Prediction Horizon: 10–30 Minutes"
          >
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-mono text-rose-300 font-bold uppercase tracking-wider">
                10–30 MIN HORIZON
              </span>
              <span className="text-[9px] font-mono text-rose-400/90">
                Potential Seizure Window
              </span>
            </div>
          </div>

          {/* 4. POST-HORIZON / BEYOND (85% to 100%) */}
          <div
            className="h-full bg-slate-900/90 flex items-center justify-center"
            style={{ width: '15%' }}
          >
            <span className="text-[9px] font-mono text-slate-500 uppercase">
              Beyond Horizon
            </span>
          </div>
        </div>

        {/* TIME TICKS UNDER THE BAR */}
        <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-2 px-1">
          <span>-45 min (Past)</span>
          <span>-20 min</span>
          <span className="text-cyan-400 font-bold">0 min (Now)</span>
          <span className="text-rose-400 font-semibold">+10 min</span>
          <span className="text-rose-400 font-semibold">+30 min</span>
          <span>+45 min (Future)</span>
        </div>

        {/* ANIMATED CURRENT TIME MARKER ("NOW" - EXACTLY AT 60%) */}
        <div
          className="absolute top-0 bottom-6 flex flex-col items-center pointer-events-none"
          style={{ left: '60%', transform: 'translateX(-50%)' }}
        >
          {/* Top Pin Label */}
          <div className="bg-cyan-500 text-slate-950 text-[10px] font-mono font-extrabold px-2 py-0.5 rounded-full shadow-[0_0_12px_rgba(6,182,212,0.8)] animate-bounce flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-950 animate-ping" />
            <span>NOW</span>
          </div>

          {/* Vertical Laser Needle */}
          <div className="w-0.5 flex-1 bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.9)]" />

          {/* Bottom Model Alert Badge */}
          <div className="mt-1 bg-slate-900/95 border border-cyan-500/60 rounded px-2 py-0.5 text-[10px] font-mono text-cyan-300 shadow-lg whitespace-nowrap">
            ▲ MODEL ALERT (Score: {prediction.riskScore}%)
          </div>
        </div>
      </div>

      {/* Descriptive Explanatory Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/70 text-xs font-mono">
        <div className="p-2.5 rounded bg-slate-900/50 border border-slate-800">
          <span className="text-slate-400 text-[10px] block uppercase">1. Past Trajectory</span>
          <p className="text-slate-300 text-[11px] mt-1 leading-snug">
            Resting 10.2 Hz background drifted into continuous 5.2 Hz rhythmic theta bursts starting at -10 min.
          </p>
        </div>

        <div className="p-2.5 rounded bg-cyan-950/20 border border-cyan-800/40">
          <span className="text-cyan-400 text-[10px] block uppercase">2. Current Detection</span>
          <p className="text-slate-300 text-[11px] mt-1 leading-snug">
            Model threshold exceeded at t=0m with {prediction.riskScore}% risk score and elevated phase synchrony.
          </p>
        </div>

        <div className="p-2.5 rounded bg-rose-950/20 border border-rose-800/40">
          <span className="text-rose-400 text-[10px] block uppercase">3. Prediction Horizon</span>
          <p className="text-slate-300 text-[11px] mt-1 leading-snug">
            Window of highest preictal susceptibility projected at 10 to 30 minutes following pattern emergence.
          </p>
        </div>
      </div>
    </div>
  );
};
