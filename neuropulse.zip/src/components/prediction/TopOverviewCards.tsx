import React from 'react';
import { Prediction } from '@/src/types';
import { Brain, ShieldAlert, Clock, Activity, CheckCircle, Info } from 'lucide-react';

interface TopOverviewCardsProps {
  prediction: Prediction;
  brainStateLabel?: string;
  signalQuality?: number;
}

export const TopOverviewCards: React.FC<TopOverviewCardsProps> = ({
  prediction,
  brainStateLabel = 'Elevated pre-seizure activity',
  signalQuality = 94,
}) => {
  const isElevated = prediction.riskScore >= 65;
  const isModerate = prediction.riskScore >= 35 && prediction.riskScore < 65;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {/* 1. BRAIN STATE CARD */}
      <div className="bg-gradient-to-br from-[#111728] to-[#0d121f] border border-slate-800 rounded-xl p-4 relative overflow-hidden shadow-lg">
        <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
          <span className="uppercase tracking-wider font-semibold text-slate-300 flex items-center gap-1.5">
            <Brain className="w-4 h-4 text-cyan-400" />
            Brain State
          </span>
          <span className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/50 px-2 py-0.5 rounded font-mono">
            <CheckCircle className="w-3 h-3" />
            Signal Quality: {signalQuality}%
          </span>
        </div>

        <div className="mt-2">
          <h3 className="text-xl font-bold text-slate-100 tracking-tight leading-snug">
            {brainStateLabel}
          </h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Associated region: <strong className="text-cyan-300 font-medium">{prediction.estimatedRegion}</strong>
          </p>
        </div>

        {/* Ambient subtle glow */}
        <div className={`absolute -right-6 -bottom-6 w-24 h-24 rounded-full blur-2xl pointer-events-none ${
          isElevated ? 'bg-rose-500/10' : isModerate ? 'bg-amber-500/10' : 'bg-cyan-500/10'
        }`} />
      </div>

      {/* 2. SEIZURE RISK (ML RISK SCORE) CARD */}
      <div className={`border rounded-xl p-4 relative overflow-hidden shadow-lg transition-all ${
        isElevated
          ? 'bg-gradient-to-br from-[#1b1424] to-[#120d1a] border-rose-800/60 shadow-[0_0_20px_rgba(244,63,94,0.12)]'
          : isModerate
          ? 'bg-gradient-to-br from-[#1c181f] to-[#121015] border-amber-800/60'
          : 'bg-gradient-to-br from-[#111728] to-[#0d121f] border-slate-800'
      }`}>
        <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
          <span className="uppercase tracking-wider font-semibold text-slate-300 flex items-center gap-1.5">
            <ShieldAlert className={`w-4 h-4 ${isElevated ? 'text-rose-400' : 'text-amber-400'}`} />
            Seizure Risk
          </span>
          <span className="text-[10px] text-slate-400 uppercase font-mono px-1.5 py-0.5 rounded bg-slate-900/80 border border-slate-800">
            ML Risk Score
          </span>
        </div>

        <div className="flex items-baseline justify-between mt-1">
          <div className="flex items-baseline gap-2">
            <span className={`text-4xl font-extrabold font-mono tracking-tight ${
              isElevated ? 'text-rose-400' : isModerate ? 'text-amber-400' : 'text-cyan-400'
            }`}>
              {prediction.riskScore}%
            </span>
            <span className={`text-xs font-bold font-mono uppercase tracking-wider px-2 py-0.5 rounded ${
              isElevated
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : isModerate
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
            }`}>
              {prediction.riskLevel} Risk
            </span>
          </div>
        </div>

        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span>Confidence: [{prediction.confidenceInterval[0]}% – {prediction.confidenceInterval[1]}%]</span>
          <span className="text-slate-500">Not clinical probability</span>
        </div>

        {/* Mini gauge track */}
        <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
          <div
            className={`h-full transition-all duration-700 ${
              isElevated ? 'bg-rose-500' : isModerate ? 'bg-amber-400' : 'bg-cyan-400'
            }`}
            style={{ width: `${prediction.riskScore}%` }}
          />
        </div>
      </div>

      {/* 3. PREDICTION WINDOW CARD */}
      <div className="bg-gradient-to-br from-[#111728] to-[#0d121f] border border-slate-800 rounded-xl p-4 relative overflow-hidden shadow-lg">
        <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
          <span className="uppercase tracking-wider font-semibold text-slate-300 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-cyan-400" />
            Prediction Window
          </span>
          <span className="text-[10px] text-slate-400 uppercase font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800">
            Temporal Horizon
          </span>
        </div>

        <div className="mt-1">
          <span className="text-3xl font-extrabold font-mono text-cyan-300 tracking-tight">
            {prediction.predictionHorizon}
          </span>
          <span className="text-xs font-bold text-slate-300 ml-2 uppercase font-mono">
            Prediction Horizon
          </span>
        </div>

        <p className="text-xs text-slate-400 mt-2 leading-relaxed">
          Target interval for estimated preictal susceptibility window based on current temporal wave features.
        </p>
      </div>
    </div>
  );
};
