import React from 'react';
import { Prediction } from '@/src/types';
import { ShieldAlert, HeartPulse, Clock, Sparkles, AlertTriangle, ArrowRight, CheckCircle2 } from 'lucide-react';

interface PatientModeViewProps {
  prediction: Prediction;
  onSwitchToClinical: () => void;
}

export const PatientModeView: React.FC<PatientModeViewProps> = ({
  prediction,
  onSwitchToClinical,
}) => {
  const isElevated = prediction.riskScore >= 65;

  return (
    <div className="max-w-3xl mx-auto py-6 px-4 space-y-6">
      {/* Patient Friendly Header Banner */}
      <div className="bg-[#111728] border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-5 h-5 text-cyan-400 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-wider text-slate-300">
              Personal EEG Monitoring Summary
            </span>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Sensor Signal Stable
          </span>
        </div>

        {/* Section 1: Brain State */}
        <div className="border-b border-slate-800/80 pb-6 mb-6">
          <span className="text-xs font-mono uppercase tracking-widest text-slate-400 block mb-1">
            Your Current Brain State
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-100 tracking-tight flex items-center gap-3">
            <span className={`w-4 h-4 rounded-full ${isElevated ? 'bg-rose-500 animate-ping' : 'bg-cyan-400'}`} />
            {isElevated ? 'Elevated Pre-Seizure Patterns' : 'Resting Baseline'}
          </h2>
          <p className="text-slate-300 text-sm mt-2 leading-relaxed max-w-xl">
            The system has detected rhythmic brainwave signals that resemble patterns commonly seen ahead of events in our research dataset.
          </p>
        </div>

        {/* Section 2: ML Risk Score & Horizon */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-b border-slate-800/80 pb-6 mb-6">
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <span className="text-xs font-mono uppercase text-slate-400 block mb-1">
              ML Risk Score
            </span>
            <div className="flex items-baseline gap-3">
              <span className={`text-4xl font-extrabold font-mono ${isElevated ? 'text-rose-400' : 'text-cyan-400'}`}>
                {prediction.riskScore}%
              </span>
              <span className={`text-xs font-bold font-mono uppercase px-2 py-0.5 rounded ${
                isElevated ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'bg-cyan-500/20 text-cyan-300'
              }`}>
                {prediction.riskLevel}
              </span>
            </div>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Calculated by our research machine learning model
            </span>
          </div>

          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <span className="text-xs font-mono uppercase text-slate-400 block mb-1">
              Estimated Time Window
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold font-mono text-cyan-300">
                10–30 min
              </span>
              <span className="text-xs text-slate-400">possible lead time</span>
            </div>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Suggested window to take a quiet rest or alert a caregiver
            </span>
          </div>
        </div>

        {/* Section 3: What does this mean? */}
        <div className="space-y-4 border-b border-slate-800/80 pb-6 mb-6">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              What does this mean?
            </h3>
            <p className="text-slate-300 text-sm mt-1 leading-relaxed">
              The system identified EEG patterns that resemble patterns observed before seizures in the research dataset. It suggests your brainwaves are currently in a heightened state of synchronization.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-mono uppercase text-slate-400">Associated Region</h4>
            <p className="text-base font-semibold text-cyan-300 mt-0.5">
              Left temporal area
            </p>
          </div>

          <div>
            <h4 className="text-xs font-mono uppercase text-slate-400">Why?</h4>
            <p className="text-sm text-slate-300 mt-0.5 leading-relaxed">
              Changes in brainwave speed (increased rhythmic slow waves), altered signal regularity, and higher synchronization between scalp sensors.
            </p>
          </div>
        </div>

        {/* Section 4: Recommended Calm Actions */}
        <div className="bg-cyan-950/20 border border-cyan-800/40 rounded-xl p-4 mb-6">
          <h4 className="text-xs font-mono uppercase text-cyan-300 font-bold mb-2">
            Recommended Protective Steps
          </h4>
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>Sit or lie down in a safe, comfortable spot away from hard corners.</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>Notify a nearby companion or caregiver of the 10–30 min alert window.</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>Avoid driving, operating machinery, or walking near water or stairs.</span>
            </li>
          </ul>
        </div>

        {/* Mandatory Safety Notice */}
        <div className="bg-amber-950/30 border border-amber-800/40 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-200/90 leading-relaxed">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            <strong>Research prototype — not a medical diagnosis.</strong> NeuroPulse is an academic study software tool. Always follow your physician's prescribed safety and emergency response protocols.
          </p>
        </div>

        {/* Switch to Detailed Research View Button */}
        <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={onSwitchToClinical}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-mono rounded-lg transition-colors"
          >
            <span>View Comprehensive Technical & EEG Signals</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
