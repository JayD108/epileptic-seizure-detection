import React, { useState } from 'react';
import { MOCK_HISTORY_EVENTS } from '@/src/lib/mock/models';
import { PatientHistoryEvent } from '@/src/types';
import { History, Calendar, CheckCircle, AlertTriangle, ArrowUpRight, Clock, Radio, Activity } from 'lucide-react';

interface PatientHistoryViewProps {
  onSelectEvent: (event: PatientHistoryEvent) => void;
}

export const PatientHistoryView: React.FC<PatientHistoryViewProps> = ({ onSelectEvent }) => {
  const [selectedEventId, setSelectedEventId] = useState<string>(MOCK_HISTORY_EVENTS[0].id);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#111728] border border-slate-800 rounded-xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-slate-100 font-mono tracking-wide">
              Longitudinal Monitoring & Prediction Event History
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Retrospective registry of detected preictal electrographic episodes, model alerts, lead times, and verified clinical outcomes.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="text-slate-400">Total Preictal Triggers:</span>
          <span className="px-2.5 py-1 rounded bg-cyan-950/60 border border-cyan-800 text-cyan-300 font-bold">
            {MOCK_HISTORY_EVENTS.length} Logged Events
          </span>
        </div>
      </div>

      {/* Visual Timeline of Events */}
      <div className="space-y-3">
        {MOCK_HISTORY_EVENTS.map((event) => {
          const isSelected = selectedEventId === event.id;
          const isHighRisk = event.peakRisk >= 75;

          return (
            <div
              key={event.id}
              onClick={() => {
                setSelectedEventId(event.id);
                onSelectEvent(event);
              }}
              className={`p-4 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-cyan-950/30 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.1)]'
                  : 'bg-[#0d121d] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-2.5 mb-3">
                <div className="flex items-center gap-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  <span className="text-xs font-mono font-bold text-slate-200">{event.date}</span>
                  <span className="text-[11px] font-mono text-slate-400 px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                    {event.recordingId}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                      isHighRisk
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    Peak Risk: {event.peakRisk}%
                  </span>
                  {event.verifiedByPhysician && (
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/50">
                      <CheckCircle className="w-3 h-3" />
                      Clinician Verified
                    </span>
                  )}
                </div>
              </div>

              {/* Event Attributes Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono mb-3">
                <div>
                  <span className="text-slate-500 text-[10px] block">Prediction Lead Time</span>
                  <span className="text-cyan-300 font-bold flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3" />
                    {event.predictionLeadMin} minutes
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 text-[10px] block">Associated Region</span>
                  <span className="text-slate-200 font-semibold mt-0.5 block">{event.estimatedRegion}</span>
                </div>

                <div>
                  <span className="text-slate-500 text-[10px] block">Associated Channels</span>
                  <div className="flex gap-1 mt-0.5">
                    {event.associatedChannels.map((ch) => (
                      <span key={ch} className="px-1.5 py-0.2 rounded bg-slate-800 text-cyan-300 text-[10px]">
                        {ch}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 text-[10px] block">Outcome Classification</span>
                  <span className="text-slate-300 font-medium text-[11px] mt-0.5 block">{event.outcome}</span>
                </div>
              </div>

              {/* Clinician & ML Notes */}
              <div className="p-2.5 rounded bg-slate-900/60 text-xs text-slate-300 border border-slate-800/80 flex items-start justify-between gap-3">
                <p className="text-[11px] leading-relaxed text-slate-300">{event.notes}</p>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectEvent(event);
                  }}
                  className="shrink-0 flex items-center gap-1 text-cyan-400 hover:text-cyan-300 text-[11px] font-mono font-semibold"
                >
                  <span>Inspect State</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
