import React from 'react';
import { BookOpen, AlertTriangle, ShieldCheck, Cpu, Activity, Brain, ExternalLink } from 'lucide-react';

export const DocsView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-[#111728] border border-slate-800 rounded-xl p-6">
        <div className="flex items-center gap-2.5">
          <BookOpen className="w-6 h-6 text-cyan-400" />
          <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
            Scientific Framework & Project Documentation
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-2 leading-relaxed">
          NeuroPulse is an academic machine learning prototype designed to explore electroencephalographic (EEG) preictal dynamics, feature explainability, and multi-scale brain state visualization.
        </p>
      </div>

      {/* Core Concept: Prediction vs Detection */}
      <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-6 space-y-3 backdrop-blur-md">
        <h3 className="text-base font-bold text-slate-100 font-mono flex items-center gap-2">
          <Brain className="w-4 h-4 text-cyan-400" />
          1. Seizure Prediction vs. Seizure Detection
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          Conventional clinical EEG monitors primarily perform <strong>seizure detection</strong>—identifying sustained high-amplitude rhythmic spike-and-wave discharges during or immediately after the onset of an active ictal event.
        </p>
        <p className="text-xs text-slate-300 leading-relaxed">
          In contrast, <strong>seizure prediction</strong> estimates preictal susceptibility windows (typically 10 to 30 minutes prior to clinical onset). It detects subtle non-linear changes in background rhythms: progressive loss of spectral complexity, emergence of localized theta/delta synchrony, and altered phase coupling between adjacent channels.
        </p>
      </div>

      {/* Feature Engineering & Model Architecture */}
      <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-6 space-y-3 backdrop-blur-md">
        <h3 className="text-base font-bold text-slate-100 font-mono flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          2. Signal Processing & Feature Engineering Pipeline
        </h3>
        <ul className="space-y-2 text-xs text-slate-300">
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
            <span><strong>Multi-Band Spectral Power:</strong> Fast Fourier Transform (FFT) and continuous Morlet wavelet transform decomposing signals into Delta (0.5–4 Hz), Theta (4–8 Hz), Alpha (8–13 Hz), Beta (13–30 Hz), and Gamma (30–45 Hz).</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
            <span><strong>Information-Theoretic Complexity:</strong> Spectral Entropy and Shannon permutation entropy to capture regularity transitions from chaotic interictal states into organized preictal rhythms.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
            <span><strong>Cross-Channel Functional Connectivity:</strong> Spectral Coherence and Phase Locking Value (PLV) across ipsilateral and contralateral electrode pairs.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
            <span><strong>Time-Domain Kinematics:</strong> Hjorth Mobility, Hjorth Complexity, and fractal Line Length.</span>
          </li>
        </ul>
      </div>

      {/* Explainable AI (SHAP) Protocol */}
      <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-6 space-y-3 backdrop-blur-md">
        <h3 className="text-base font-bold text-slate-100 font-mono flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          3. Model Explainability via TreeSHAP
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          Machine learning in neuroscience must not operate as an opaque black box. NeuroPulse incorporates Shapley Additive Explanations (SHAP) based on cooperative game theory to quantify the exact marginal contribution of each biometric signal attribute to the output risk score.
        </p>
        <p className="text-xs text-slate-400 font-mono">
          Note: Feature importance scores reflect statistical contributions within the trained decision trees; they identify strong mathematical correlates rather than establishing direct biological causality.
        </p>
      </div>

      {/* Mandatory Regulatory & Ethics Disclaimer */}
      <div className="p-6 rounded-xl bg-amber-950/25 border border-amber-800/60 text-xs text-amber-200/90 space-y-2">
        <div className="flex items-center gap-2 font-bold font-mono text-amber-300 uppercase text-sm">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
          <span>Academic Prototype & Safety Limitations Disclaimer</span>
        </div>
        <p className="leading-relaxed">
          NeuroPulse is an academic computer science and biomedical engineering demonstration application developed for research, education, and algorithm evaluation. It is <strong>NOT a medical device</strong>, has not undergone clinical trials or regulatory approval (FDA / CE mark), and must not be used for clinical diagnosis, patient management, or medication decisions.
        </p>
      </div>
    </div>
  );
};
