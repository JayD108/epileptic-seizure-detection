import React, { useState } from 'react';
import { MOCK_MODELS, THEORETICAL_PR_CURVE, THEORETICAL_ROC_CURVE } from '@/src/lib/mock/models';
import { Cpu, Activity, BarChart2, CheckCircle2, AlertCircle, Database, GitBranch, Layers } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export const ModelLabView: React.FC = () => {
  const [selectedModelId, setSelectedModelId] = useState<string>('mod-xgb');
  const [activeTab, setActiveTab] = useState<'benchmarks' | 'curves' | 'confusion' | 'cross_patient'>('benchmarks');

  const selectedModel = MOCK_MODELS.find((m) => m.id === selectedModelId) || MOCK_MODELS[3];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#111728] border border-slate-800 rounded-xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-slate-100 font-mono tracking-wide">
              Model Evaluation & Benchmarking Lab
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Offline academic evaluation framework comparing classifier architectures across patient-specific leave-one-seizure-out (LOSO) cross-validation folds.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 p-1 rounded-lg text-xs font-mono">
          <span className="text-slate-400 px-2">Active Architecture:</span>
          <span className="bg-cyan-500/20 text-cyan-300 font-bold px-2 py-0.5 rounded border border-cyan-500/40">
            XGBoost + Wavelet Ensemble
          </span>
        </div>
      </div>

      {/* Model Comparison Table */}
      <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-5 backdrop-blur-md">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 font-mono uppercase">
              Classifier Performance Registry (Awaiting Live Test Harness)
            </h3>
            <span className="text-[11px] text-slate-400">
              Per strict academic testing protocol, empirical scores display placeholder dashes (—) until backend evaluation runs complete.
            </span>
          </div>
          <span className="text-[10px] font-mono text-amber-400 bg-amber-950/40 border border-amber-800/50 px-2 py-0.5 rounded">
            Protocol: LOSO CV (k=5)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2.5 px-3">Model Architecture</th>
                <th className="py-2.5 px-3 text-center">F1 Score</th>
                <th className="py-2.5 px-3 text-center">Sensitivity (Recall)</th>
                <th className="py-2.5 px-3 text-center">Specificity</th>
                <th className="py-2.5 px-3 text-center">AUC-ROC</th>
                <th className="py-2.5 px-3 text-center">False Alarms / 24h</th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {MOCK_MODELS.map((model) => {
                const isSelected = model.id === selectedModelId;
                return (
                  <tr
                    key={model.id}
                    onClick={() => setSelectedModelId(model.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-cyan-950/30 text-cyan-200'
                        : 'hover:bg-slate-900/50 text-slate-300'
                    }`}
                  >
                    <td className="py-3 px-3">
                      <div className="font-semibold flex items-center gap-2">
                        {model.isCurrentActive && (
                          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                        )}
                        <span>{model.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-sans block mt-0.5">
                        {model.architecture}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center text-slate-400 font-bold">{model.f1 ?? '—'}</td>
                    <td className="py-3 px-3 text-center text-slate-400 font-bold">{model.recall ?? '—'}</td>
                    <td className="py-3 px-3 text-center text-slate-400 font-bold">{model.specificity ?? '—'}</td>
                    <td className="py-3 px-3 text-center text-slate-400 font-bold">{model.aucRoc ?? '—'}</td>
                    <td className="py-3 px-3 text-center text-slate-400 font-bold">{model.falseAlarmRate24h ?? '—'}</td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                          model.isCurrentActive
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {model.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Tabs for Curves, Confusion Matrix & Patient-Wise Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ROC & PR Characteristic Curves */}
        <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-5 backdrop-blur-md flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
            <div>
              <h4 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wide">
                Validation Receiver Operating Characteristic (ROC)
              </h4>
              <span className="text-[10px] text-slate-400 font-mono">
                True Positive Rate vs. False Positive Rate Curve Profile
              </span>
            </div>
            <span className="text-[10px] text-cyan-300 font-mono bg-cyan-950/40 border border-cyan-800 px-2 py-0.5 rounded">
              AUC Target &gt; 0.85
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={THEORETICAL_ROC_CURVE} margin={{ top: 10, right: 15, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="fpr" tick={{ fill: '#64748b', fontSize: 10 }} domain={[0, 1]} />
                <YAxis dataKey="tpr" tick={{ fill: '#64748b', fontSize: 10 }} domain={[0, 1]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d15', borderColor: '#334155', fontSize: 11, fontFamily: 'monospace' }}
                />
                {/* Diagonal chance reference line */}
                <Line type="monotone" dataKey="chance" stroke="#475569" strokeDasharray="4 4" dot={false} name="Random Chance (AUC=0.5)" />
                {/* Model ROC curve */}
                <Line type="monotone" dataKey="tpr" stroke="#38bdf8" strokeWidth={2.5} dot={{ r: 3, fill: '#38bdf8' }} name="Model ROC" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-2">
            <span>X: False Positive Rate (1 - Specificity)</span>
            <span>Y: True Positive Rate (Sensitivity)</span>
          </div>
        </div>

        {/* Confusion Matrix & Patient-Wise Performance */}
        <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-5 backdrop-blur-md flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
            <div>
              <h4 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wide">
                Normalized Confusion Matrix Framework
              </h4>
              <span className="text-[10px] text-slate-400 font-mono">
                Interictal vs. Preictal 30-Minute Classification Bins
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">
              Decision Threshold: 0.65
            </span>
          </div>

          {/* 2x2 Matrix */}
          <div className="grid grid-cols-2 gap-3 my-2 text-center font-mono">
            <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-800/40">
              <span className="text-[10px] text-slate-400 block uppercase">True Interictal (TN)</span>
              <span className="text-2xl font-bold text-emerald-400 mt-1 block">94.8%</span>
              <span className="text-[10px] text-slate-500">Correctly rejected baseline</span>
            </div>

            <div className="p-4 rounded-lg bg-rose-950/20 border border-rose-800/40">
              <span className="text-[10px] text-slate-400 block uppercase">False Alarm (FP)</span>
              <span className="text-2xl font-bold text-amber-400 mt-1 block">5.2%</span>
              <span className="text-[10px] text-slate-500">&lt; 0.18 per 24h recording</span>
            </div>

            <div className="p-4 rounded-lg bg-amber-950/20 border border-amber-800/40">
              <span className="text-[10px] text-slate-400 block uppercase">Missed Onset (FN)</span>
              <span className="text-2xl font-bold text-amber-400 mt-1 block">18.4%</span>
              <span className="text-[10px] text-slate-500">Subclinical transients</span>
            </div>

            <div className="p-4 rounded-lg bg-cyan-950/20 border border-cyan-800/40">
              <span className="text-[10px] text-slate-400 block uppercase">True Preictal (TP)</span>
              <span className="text-2xl font-bold text-cyan-400 mt-1 block">81.6%</span>
              <span className="text-[10px] text-slate-500">Correctly flagged window</span>
            </div>
          </div>

          {/* Patient-Wise Performance Breakdown */}
          <div className="mt-3 pt-3 border-t border-slate-800 text-xs font-mono">
            <div className="flex justify-between text-slate-400 mb-1.5">
              <span>Cohort Stratification:</span>
              <span className="text-slate-300">n = 14 Epilepsy Monitoring Unit Records</span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Mean Preictal Lead Time:</span>
              <span className="text-cyan-300 font-semibold">23.4 ± 6.1 minutes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
