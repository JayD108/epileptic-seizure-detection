import React, { useState } from 'react';
import { generateReport } from '@/src/lib/api';
import { SystemReport } from '@/src/types';
import { FileText, Download, Printer, CheckCircle, ShieldAlert, AlertTriangle, Sparkles, Building } from 'lucide-react';

interface ReportsViewProps {
  patientId: string;
  recordingId: string;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ patientId, recordingId }) => {
  const [report, setReport] = useState<SystemReport | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  // Generate on demand or default
  React.useEffect(() => {
    generateReport(patientId, recordingId).then(setReport);
  }, [patientId, recordingId]);

  const handleGeneratePDF = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    }, 1200);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!report) return null;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Action Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#111728] border border-slate-800 rounded-xl p-5">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-slate-100 font-mono tracking-wide">
              Academic Neuro-Engineering Diagnostic Report
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Standardized technical summary of EEG feature extraction, predictive horizon, and SHAP explainability metrics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-mono rounded-lg transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print View</span>
          </button>

          <button
            type="button"
            onClick={handleGeneratePDF}
            disabled={isGenerating}
            className="flex items-center gap-2 px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs font-mono rounded-lg transition-colors shadow-md disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isGenerating ? 'Compiling PDF...' : downloadSuccess ? 'Downloaded!' : 'Generate Report (PDF)'}</span>
          </button>
        </div>
      </div>

      {/* Main Document Preview Paper */}
      <div className="bg-[#0b0f17] border border-slate-800 rounded-xl p-8 shadow-2xl space-y-6 text-slate-200 print:bg-white print:text-black print:border-none">
        {/* Document Title Header */}
        <div className="border-b border-slate-800 pb-6 flex flex-wrap justify-between items-start gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-bold uppercase tracking-widest mb-1">
              <Building className="w-4 h-4" />
              <span>{report.institution}</span>
            </div>
            <h1 className="text-2xl font-bold font-mono text-slate-100 tracking-tight">
              Preictal Electrographic Prediction Dossier
            </h1>
            <span className="text-xs text-slate-400 font-mono block mt-1">
              Document Ref: <strong>{report.id}</strong> • Protocol: Automated LOSO-ML
            </span>
          </div>

          <div className="text-right text-xs font-mono text-slate-400">
            <div>Generated: {new Date(report.generatedAt).toLocaleString()}</div>
            <div className="text-cyan-400 font-semibold">{report.primaryInvestigator}</div>
          </div>
        </div>

        {/* Section 1: Recording Information & Signal Quality */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-900/60 border border-slate-800 text-xs font-mono">
          <div>
            <span className="text-slate-500 text-[10px] block uppercase">Patient Identifier</span>
            <span className="text-slate-100 font-bold text-sm">{report.patientId}</span>
          </div>
          <div>
            <span className="text-slate-500 text-[10px] block uppercase">Recording Session</span>
            <span className="text-slate-100 font-bold">{report.recordingId}</span>
          </div>
          <div>
            <span className="text-slate-500 text-[10px] block uppercase">Signal Quality Metric</span>
            <span className="text-emerald-400 font-bold">{report.signalQuality}% (Artifact-Rejected)</span>
          </div>
          <div>
            <span className="text-slate-500 text-[10px] block uppercase">Epoch Window Duration</span>
            <span className="text-slate-100 font-bold">{report.recordingDuration}</span>
          </div>
        </div>

        {/* Section 2: Prediction Summary */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold font-mono uppercase text-slate-100 border-b border-slate-800/80 pb-1.5 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            1. Predictive Risk & Horizon Assessment
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
            <div className="p-3 bg-rose-950/20 border border-rose-800/40 rounded-lg">
              <span className="text-slate-400 text-[10px] block uppercase">Peak ML Risk Score</span>
              <span className="text-2xl font-extrabold text-rose-400">{report.predictionSummary.peakRisk}%</span>
              <span className="text-[10px] text-rose-300 block mt-0.5 uppercase">ELEVATED PREICTAL STATE</span>
            </div>
            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
              <span className="text-slate-400 text-[10px] block uppercase">Prediction Horizon</span>
              <span className="text-2xl font-extrabold text-cyan-300">{report.predictionSummary.predictionHorizon}</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Estimated Lead Time</span>
            </div>
            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
              <span className="text-slate-400 text-[10px] block uppercase">Estimated Cortical Region</span>
              <span className="text-base font-bold text-slate-100">{report.predictionSummary.estimatedRegion}</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Leads: {report.predictionSummary.associatedChannels.join(', ')}</span>
            </div>
          </div>
        </div>

        {/* Section 3: Feature Contributions (SHAP) */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold font-mono uppercase text-slate-100 border-b border-slate-800/80 pb-1.5 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            2. Dominant Feature Attributions (TreeSHAP)
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs divide-y divide-slate-800">
              <thead>
                <tr className="text-slate-400 text-[10px] uppercase">
                  <th className="py-2">Extracted Feature</th>
                  <th className="py-2">Attribution Contribution</th>
                  <th className="py-2">Shift from Interictal Norm</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {report.dominantFeatures.map((f, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/40">
                    <td className="py-2.5 font-semibold text-slate-200">{f.feature}</td>
                    <td className="py-2.5 font-bold text-rose-400">{f.contribution}</td>
                    <td className="py-2.5 text-slate-400">{f.baselineShift}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 4: Model Architecture & Evaluation Context */}
        <div className="space-y-2 text-xs font-mono">
          <h3 className="text-sm font-bold font-mono uppercase text-slate-100 border-b border-slate-800/80 pb-1.5">
            3. Algorithmic Architecture & Verification
          </h3>
          <p className="text-slate-300 leading-relaxed font-sans text-xs">
            Model: <strong>XGBoost + Continuous Morlet Wavelet Ensemble (v1.4-rc2)</strong>. Feature vector comprises multi-band spectral power ratios (Delta, Theta, Alpha, Beta, Gamma), instantaneous spectral entropy, phase locking values (PLV), and Hjorth complexity descriptors computed over sliding 4.0-second Hanning epochs.
          </p>
        </div>

        {/* Section 5: Mandatory Academic Disclaimer & Limitations */}
        <div className="p-4 rounded-lg bg-amber-950/20 border border-amber-800/50 text-xs font-mono text-amber-200/90 leading-relaxed space-y-1.5">
          <div className="flex items-center gap-2 font-bold uppercase text-amber-300">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Academic Research Limitations & Regulatory Disclaimer</span>
          </div>
          <p className="text-[11px] font-sans">
            {report.limitationsDisclaimer}
          </p>
        </div>
      </div>
    </div>
  );
};
