import React from 'react';
import { FrequencyBand } from '@/src/types';
import { FREQUENCY_BANDS } from '@/src/lib/mock/eeg';
import { Radio, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface FrequencyBandPanelProps {
  selectedChannelId?: string;
  preictalSeverity?: number;
}

export const FrequencyBandPanel: React.FC<FrequencyBandPanelProps> = ({
  selectedChannelId = 'T3',
  preictalSeverity = 0.73,
}) => {
  // Dynamically calculate band distribution based on channel and preictal severity
  const isFocal = selectedChannelId === 'T3' || selectedChannelId === 'T5';

  const bands: FrequencyBand[] = FREQUENCY_BANDS.map((band) => {
    if (band.name === 'Theta') {
      const deltaShift = isFocal ? Math.round(31 * (preictalSeverity / 0.73)) : 8;
      const relPower = isFocal ? Math.min(65, 39 + Math.round(preictalSeverity * 15)) : 22;
      return {
        ...band,
        relativePower: relPower,
        baselineDeltaPercent: deltaShift,
      };
    } else if (band.name === 'Alpha') {
      const deltaShift = isFocal ? -12 : +8;
      return {
        ...band,
        relativePower: isFocal ? 18 : 34,
        baselineDeltaPercent: deltaShift,
      };
    }
    return band;
  });

  return (
    <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-3.5 backdrop-blur-md">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5 mb-3">
        <div>
          <h4 className="text-xs font-semibold text-slate-200 font-mono tracking-wide uppercase flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-purple-400" />
            Frequency Band Decomposition
          </h4>
          <span className="text-[10px] text-slate-400 font-mono">
            Lead: <strong>{selectedChannelId}</strong> • Relative Power & Baseline Shift
          </span>
        </div>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
          Fast Fourier Transform (FFT)
        </span>
      </div>

      <div className="space-y-2.5">
        {bands.map((b) => {
          const isTheta = b.name === 'Theta';
          const isPositive = b.baselineDeltaPercent > 0;
          const isZero = b.baselineDeltaPercent === 0;

          return (
            <div key={b.name} className="p-2 rounded-lg bg-slate-900/40 border border-slate-800/60">
              <div className="flex items-center justify-between text-xs font-mono mb-1">
                <div className="flex items-center gap-2">
                  <span className={`font-bold ${isTheta ? 'text-rose-400' : 'text-slate-200'}`}>
                    {b.name}
                  </span>
                  <span className="text-[10px] text-slate-500">({b.range})</span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-slate-300 font-semibold">{b.relativePower}%</span>
                  <span
                    className={`text-[11px] font-bold flex items-center gap-0.5 ${
                      isTheta && isPositive
                        ? 'text-rose-400'
                        : isPositive
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {isPositive ? <TrendingUp className="w-3 h-3" /> : isZero ? <Minus className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    {isPositive ? `+${b.baselineDeltaPercent}%` : `${b.baselineDeltaPercent}%`}
                  </span>
                </div>
              </div>

              {/* Bar indicator */}
              <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden flex items-center">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    isTheta
                      ? 'bg-gradient-to-r from-rose-500 to-amber-400'
                      : b.name === 'Alpha'
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500'
                      : 'bg-purple-500/70'
                  }`}
                  style={{ width: `${Math.min(b.relativePower * 1.5, 100)}%` }}
                />
              </div>

              <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
                <span>Abs: {b.absolutePower} µV²/Hz</span>
                <span>Signal Characteristic</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
