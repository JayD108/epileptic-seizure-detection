import React, { useMemo, useState } from 'react';
import { generateSpectrogramData } from '@/src/lib/mock/eeg';
import { CHANNEL_METADATA } from '@/src/lib/mock/eeg';
import { Sliders, Layers, Info } from 'lucide-react';

interface SpectrogramViewerProps {
  selectedChannelId: string;
  onSelectChannel: (channelId: string) => void;
  preictalSeverity?: number;
}

export const SpectrogramViewer: React.FC<SpectrogramViewerProps> = ({
  selectedChannelId,
  onSelectChannel,
  preictalSeverity = 0.73,
}) => {
  const [maxFreqHz, setMaxFreqHz] = useState<number>(40);
  const [timeRangeSec, setTimeRangeSec] = useState<number>(30);
  const [normalization, setNormalization] = useState<'dB' | 'power' | 'zscore'>('dB');

  const spectrogramData = useMemo(() => {
    return generateSpectrogramData(selectedChannelId, 24, preictalSeverity);
  }, [selectedChannelId, preictalSeverity]);

  // Frequency bands
  const freqLabels = [
    { hz: 40, label: '40 Hz (Gamma)' },
    { hz: 30, label: '30 Hz (Beta)' },
    { hz: 20, label: '20 Hz' },
    { hz: 13, label: '13 Hz (Alpha)' },
    { hz: 8, label: '8 Hz (Theta)' },
    { hz: 4, label: '4 Hz (Delta)' },
    { hz: 0, label: '0 Hz' },
  ];

  // Colormap function (Dark Indigo -> Cyan -> Amber -> Coral/Red)
  const getPowerColor = (val: number, maxVal: number = 70) => {
    const ratio = Math.min(Math.max(val / maxVal, 0), 1);
    if (ratio < 0.25) {
      // Dark navy to deep purple/blue
      const t = ratio / 0.25;
      return `rgb(${Math.round(15 + t * 25)}, ${Math.round(23 + t * 45)}, ${Math.round(42 + t * 120)})`;
    } else if (ratio < 0.55) {
      // Deep blue to cyan
      const t = (ratio - 0.25) / 0.3;
      return `rgb(${Math.round(40 + t * 20)}, ${Math.round(68 + t * 140)}, ${Math.round(162 + t * 70)})`;
    } else if (ratio < 0.8) {
      // Cyan to amber
      const t = (ratio - 0.55) / 0.25;
      return `rgb(${Math.round(60 + t * 185)}, ${Math.round(208 - t * 50)}, ${Math.round(232 - t * 190)})`;
    } else {
      // Amber to glowing Coral/Crimson
      const t = (ratio - 0.8) / 0.2;
      return `rgb(${Math.round(245 + t * 10)}, ${Math.round(158 - t * 90)}, ${Math.round(42 + t * 50)})`;
    }
  };

  return (
    <div className="bg-[#0d121d] border border-slate-800 rounded-xl p-3.5 backdrop-blur-md">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <h4 className="text-xs font-semibold text-slate-200 font-mono tracking-wide uppercase flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            Time-Frequency Spectrogram (STFT)
          </h4>
          <span className="text-[10px] text-slate-400 font-mono">
            Hanning Window • 1.25s Resolution
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap text-xs font-mono">
          {/* Channel dropdown */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded px-2 py-0.5">
            <span className="text-slate-400 text-[11px]">Channel:</span>
            <select
              value={selectedChannelId}
              onChange={(e) => onSelectChannel(e.target.value)}
              className="bg-transparent text-cyan-300 font-bold py-0.5 focus:outline-none"
            >
              {CHANNEL_METADATA.map((c) => (
                <option key={c.id} value={c.id} className="bg-slate-900 text-slate-200">
                  {c.label} ({c.region})
                </option>
              ))}
            </select>
          </div>

          {/* Normalization toggle */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5">
            <span className="text-slate-500 text-[10px]">Scale:</span>
            {(['dB', 'power', 'zscore'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setNormalization(mode)}
                className={`px-1.5 py-0.5 rounded text-[10px] uppercase ${
                  normalization === mode ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* Freq Range */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5">
            <span className="text-slate-500 text-[10px]">Max Freq:</span>
            {[30, 40].map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setMaxFreqHz(f)}
                className={`px-1.5 py-0.5 rounded text-[10px] ${
                  maxFreqHz === f ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                }`}
              >
                {f}Hz
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Spectrogram Matrix Plot */}
      <div className="relative flex h-[170px] w-full border border-slate-800/80 rounded-lg overflow-hidden bg-[#070a11]">
        {/* Frequency Y-Axis Labels */}
        <div className="w-14 shrink-0 flex flex-col justify-between py-2 pl-2 pr-1 border-r border-slate-800/80 text-[10px] font-mono text-slate-400">
          <span>40 Hz</span>
          <span className="text-purple-300">30 Hz</span>
          <span>20 Hz</span>
          <span className="text-cyan-300">10 Hz</span>
          <span className="text-rose-400 font-bold">5 Hz ★</span>
          <span>0 Hz</span>
        </div>

        {/* Heatmap Grid Cells */}
        <div className="flex-1 flex flex-col justify-between h-full p-1 relative">
          {/* Preictal Theta slowing highlighted band overlay */}
          <div
            className="absolute left-0 right-0 pointer-events-none border-y border-dashed border-rose-500/40 bg-rose-500/5 z-10"
            style={{ top: '65%', height: '22%' }}
            title="Preictal Theta Slowing Band (4–8 Hz)"
          >
            <span className="absolute right-2 top-0.5 text-[9px] font-mono text-rose-300 bg-slate-900/80 px-1 rounded">
              Theta Slowing Window (4–8 Hz)
            </span>
          </div>

          {/* Spectrogram 2D grid */}
          <div className="w-full h-full grid grid-cols-24 gap-[1px]">
            {spectrogramData.map((slice, sIdx) => {
              // Reversed frequencies (high frequency at top, 0Hz at bottom)
              const reversedFreqs = [...slice.frequencies].reverse();
              return (
                <div key={slice.timeLabel} className="flex flex-col h-full gap-[1px]">
                  {reversedFreqs.map((f, fIdx) => (
                    <div
                      key={f.hz}
                      className="flex-1 transition-colors hover:brightness-150 cursor-crosshair"
                      style={{
                        backgroundColor: getPowerColor(f.power, 65),
                      }}
                      title={`Time: ${slice.timeLabel} | Freq: ${f.hz} Hz | Power: ${f.power} µV²/Hz`}
                    />
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Time X-Axis and Colorbar Legend */}
      <div className="flex items-center justify-between mt-2 text-[10px] font-mono text-slate-400">
        <div className="flex items-center gap-6 pl-14">
          <span>0.0s</span>
          <span>7.5s</span>
          <span>15.0s</span>
          <span>22.5s</span>
          <span>30.0s (Live)</span>
        </div>

        {/* Spectral Density Legend Bar */}
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Power: Low</span>
          <div className="w-24 h-2 rounded-full bg-gradient-to-r from-slate-900 via-cyan-500 to-rose-500" />
          <span className="text-rose-400 font-semibold">High (Preictal)</span>
        </div>
      </div>
    </div>
  );
};
