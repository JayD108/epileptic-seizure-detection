import React, { useEffect, useRef, useState } from 'react';
import { EEGChannel } from '@/src/types';
import { generateSyntheticEEG } from '@/src/lib/mock/eeg';
import { Play, Pause, ZoomIn, ZoomOut, Maximize2, Sliders, Filter, Sparkles, Volume2 } from 'lucide-react';

interface EEGViewerProps {
  selectedChannelId: string | null;
  onSelectChannel: (channelId: string) => void;
  preictalSeverity?: number;
  className?: string;
}

export const EEGViewer: React.FC<EEGViewerProps> = ({
  selectedChannelId,
  onSelectChannel,
  preictalSeverity = 0.73,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [timeWindowSec, setTimeWindowSec] = useState<number>(4); // 2s, 4s, 8s
  const [gainScale, setGainScale] = useState<number>(1.0); // 0.5x, 1x, 2x
  const [filterMode, setFilterMode] = useState<'all' | 'temporal' | 'focal' | 'anterior' | 'posterior'>('all');
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [channels, setChannels] = useState<EEGChannel[]>(() => generateSyntheticEEG(360, 0, preictalSeverity));

  const timeOffsetRef = useRef<number>(0);

  // Update channels when severity or time changes
  useEffect(() => {
    setChannels(generateSyntheticEEG(360, timeOffsetRef.current, preictalSeverity));
  }, [preictalSeverity]);

  // Canvas drawing loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();

    const render = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      if (isPlaying) {
        timeOffsetRef.current += delta * 60 * speedMultiplier;
      }

      // Handle high-DPI
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = rect.width;
      const height = rect.height;

      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      // Background
      ctx.fillStyle = '#0a0e17';
      ctx.fillRect(0, 0, width, height);

      // Filter channels based on filterMode
      let visibleChannels = channels;
      if (filterMode === 'temporal') {
        visibleChannels = channels.filter((c) => ['T3', 'T4', 'T5', 'T6'].includes(c.id));
      } else if (filterMode === 'focal') {
        visibleChannels = channels.filter((c) => ['T3', 'T5', 'C3', 'F3'].includes(c.id));
      } else if (filterMode === 'anterior') {
        visibleChannels = channels.filter((c) => ['Fp1', 'Fp2', 'F3', 'F4', 'Fz'].includes(c.id));
      } else if (filterMode === 'posterior') {
        visibleChannels = channels.filter((c) => ['P3', 'P4', 'Pz', 'O1', 'O2'].includes(c.id));
      }

      const numChannels = visibleChannels.length;
      if (numChannels === 0) {
        ctx.restore();
        animationFrameRef.current = requestAnimationFrame(render);
        return;
      }

      const labelWidth = 55;
      const plotWidth = width - labelWidth - 20;
      const channelHeight = height / (numChannels + 0.5);

      // Draw Grid lines (Time seconds)
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
      ctx.lineWidth = 1;
      const secStep = plotWidth / timeWindowSec;
      for (let s = 0; s <= timeWindowSec; s++) {
        const x = labelWidth + s * secStep;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height - 20);
        ctx.stroke();

        // Time label at bottom
        ctx.fillStyle = '#64748b';
        ctx.font = '10px JetBrains Mono, monospace';
        ctx.fillText(`+${s.toFixed(1)}s`, x - 12, height - 6);
      }

      // Generate animated sample buffer
      const currentOffset = timeOffsetRef.current;
      const activeChannelsData = generateSyntheticEEG(
        Math.floor(timeWindowSec * 60),
        currentOffset,
        preictalSeverity
      );

      // Render each visible channel
      visibleChannels.forEach((ch, idx) => {
        const chData = activeChannelsData.find((c) => c.id === ch.id) || ch;
        const centerY = (idx + 0.8) * channelHeight;
        const isSelected = selectedChannelId === ch.id;
        const isFocal = ch.id === 'T3' || ch.id === 'T5';

        // Horizontal channel baseline divider
        ctx.strokeStyle = 'rgba(30, 41, 59, 0.3)';
        ctx.beginPath();
        ctx.moveTo(labelWidth, centerY);
        ctx.lineTo(width, centerY);
        ctx.stroke();

        // Channel Label
        ctx.fillStyle = isSelected
          ? '#38bdf8'
          : isFocal && preictalSeverity > 0.5
          ? '#f43f5e'
          : '#94a3b8';
        ctx.font = isSelected ? 'bold 11px JetBrains Mono, monospace' : '10px JetBrains Mono, monospace';
        ctx.fillText(ch.label, 12, centerY + 3);

        // Highlight background for selected channel
        if (isSelected) {
          ctx.fillStyle = 'rgba(56, 189, 248, 0.07)';
          ctx.fillRect(0, centerY - channelHeight * 0.45, width, channelHeight * 0.9);
        }

        // Draw EEG Waveform
        const samples = chData.samples;
        const ptsCount = samples.length;
        if (ptsCount === 0) return;

        ctx.beginPath();
        const stepX = plotWidth / (ptsCount - 1);

        for (let i = 0; i < ptsCount; i++) {
          const x = labelWidth + i * stepX;
          // Scale amplitude: 1 uV = approx 0.4px * gainScale
          const y = centerY - (samples[i] * 0.38 * gainScale);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }

        ctx.lineWidth = isSelected ? 2.0 : isFocal ? 1.6 : 1.1;
        ctx.strokeStyle = isSelected
          ? '#38bdf8'
          : isFocal && preictalSeverity > 0.5
          ? '#f43f5e'
          : '#60a5fa';
        ctx.stroke();
      });

      // Moving Current Time Sweep Marker
      const sweepX = labelWidth + ((timeOffsetRef.current % (timeWindowSec * 60)) / (timeWindowSec * 60)) * plotWidth;
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(sweepX, 0);
      ctx.lineTo(sweepX, height - 20);
      ctx.stroke();
      ctx.setLineDash([]);

      // 50 µV / 1s Scale indicator in bottom-left
      ctx.fillStyle = '#64748b';
      ctx.fillRect(labelWidth + 10, height - 24, 40, 1.5); // 1 sec approx
      ctx.fillRect(labelWidth + 10, height - 34, 1.5, 10); // 50 uV
      ctx.font = '9px JetBrains Mono, monospace';
      ctx.fillText('50 µV', labelWidth + 16, height - 28);

      ctx.restore();
      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isPlaying, timeWindowSec, gainScale, filterMode, speedMultiplier, channels, selectedChannelId, preictalSeverity]);

  // Handle canvas click to select channel
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickY = e.clientY - rect.top;

    let visibleChannels = channels;
    if (filterMode === 'temporal') {
      visibleChannels = channels.filter((c) => ['T3', 'T4', 'T5', 'T6'].includes(c.id));
    } else if (filterMode === 'focal') {
      visibleChannels = channels.filter((c) => ['T3', 'T5', 'C3', 'F3'].includes(c.id));
    } else if (filterMode === 'anterior') {
      visibleChannels = channels.filter((c) => ['Fp1', 'Fp2', 'F3', 'F4', 'Fz'].includes(c.id));
    } else if (filterMode === 'posterior') {
      visibleChannels = channels.filter((c) => ['P3', 'P4', 'Pz', 'O1', 'O2'].includes(c.id));
    }

    const channelHeight = rect.height / (visibleChannels.length + 0.5);
    const clickedIndex = Math.floor(clickY / channelHeight);

    if (clickedIndex >= 0 && clickedIndex < visibleChannels.length) {
      onSelectChannel(visibleChannels[clickedIndex].id);
    }
  };

  return (
    <div className={`bg-[#0d121d] border border-slate-800 rounded-xl p-3.5 backdrop-blur-md flex flex-col ${className}`}>
      {/* Viewer Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-700/70 font-mono text-xs text-slate-200">
            <span className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
            <span>{isPlaying ? 'LIVE STREAM' : 'PAUSED'}</span>
          </div>

          <span className="text-xs text-slate-400 font-mono hidden sm:inline">
            256 Hz • 17 Channels • 10–20 Montage
          </span>
        </div>

        {/* Playback & View Config Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Play/Pause */}
          <button
            type="button"
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-xs font-mono text-slate-200 transition-colors"
          >
            {isPlaying ? <Pause className="w-3 h-3 text-amber-400" /> : <Play className="w-3 h-3 text-emerald-400" />}
            <span>{isPlaying ? 'Pause' : 'Resume'}</span>
          </button>

          {/* Speed */}
          <button
            type="button"
            onClick={() => setSpeedMultiplier(speedMultiplier === 1 ? 2 : 1)}
            className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-xs font-mono text-slate-300 transition-colors"
            title="Toggle playback speed"
          >
            {speedMultiplier}x
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Filter Montage Dropdown */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded px-2 py-0.5">
            <Filter className="w-3 h-3 text-cyan-400" />
            <select
              value={filterMode}
              onChange={(e) => setFilterMode(e.target.value as any)}
              className="bg-transparent text-xs font-mono text-slate-200 py-1 focus:outline-none"
            >
              <option value="all">All Channels (17)</option>
              <option value="temporal">Temporal (T3–T6)</option>
              <option value="focal">Focal Preictal (T3, T5, C3, F3)</option>
              <option value="anterior">Anterior (Frontal)</option>
              <option value="posterior">Posterior (Parietal/Occipital)</option>
            </select>
          </div>

          {/* Time Window Zoom */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-xs font-mono text-slate-300">
            <span className="text-slate-500 text-[10px]">Window:</span>
            {[2, 4, 8].map((sec) => (
              <button
                key={sec}
                type="button"
                onClick={() => setTimeWindowSec(sec)}
                className={`px-1.5 py-0.5 rounded text-[11px] ${
                  timeWindowSec === sec ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sec}s
              </button>
            ))}
          </div>

          {/* Gain Amplitude Scale */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-xs font-mono text-slate-300">
            <span className="text-slate-500 text-[10px]">Gain:</span>
            {[0.5, 1, 2].map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => setGainScale(g)}
                className={`px-1.5 py-0.5 rounded text-[11px] ${
                  gainScale === g ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {g}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Waveform Canvas */}
      <div className="relative w-full h-[360px] rounded-lg overflow-hidden border border-slate-900 bg-[#090d15] cursor-pointer">
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="w-full h-full block"
        />

        {/* Selected Channel Badge */}
        {selectedChannelId && (
          <div className="absolute top-2 right-2 px-2 py-1 bg-slate-900/90 backdrop-blur-md border border-cyan-500/40 rounded text-xs font-mono text-cyan-300 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>Active Channel: <strong>{selectedChannelId}</strong></span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 font-mono">
        <span>Click any channel label or waveform trace to cross-filter spectrogram & 3D brain locus.</span>
        <span className="text-slate-500">Amplitude: ±100 µV FSR</span>
      </div>
    </div>
  );
};
