import React from 'react';
import {
  LayoutDashboard,
  Brain,
  Activity,
  Sparkles,
  GitCommit,
  Cpu,
  History,
  FileText,
  Sliders,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

export type NavigationPage =
  | 'overview'
  | 'brain'
  | 'eeg'
  | 'explainability'
  | 'connectivity'
  | 'models'
  | 'history'
  | 'reports'
  | 'docs';

interface SidebarProps {
  currentPage: NavigationPage;
  onSelectPage: (page: NavigationPage) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onSelectPage,
  isCollapsed,
  onToggleCollapse,
}) => {
  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard, badge: null },
    { id: 'brain', label: '3D Brain Activity', icon: Brain, badge: '3D' },
    { id: 'eeg', label: 'EEG Waveforms', icon: Activity, badge: '17ch' },
    { id: 'explainability', label: 'Explainability (SHAP)', icon: Sparkles, badge: null },
    { id: 'connectivity', label: 'Connectivity Graph', icon: GitCommit, badge: null },
    { id: 'models', label: 'Model Evaluation Lab', icon: Cpu, badge: 'LOSO' },
    { id: 'history', label: 'Patient Event History', icon: History, badge: null },
    { id: 'reports', label: 'Diagnostic Reports', icon: FileText, badge: 'PDF' },
    { id: 'docs', label: 'Documentation & Ethics', icon: HelpCircle, badge: null },
  ] as const;

  return (
    <aside
      className={`border-r border-slate-800 bg-[#0a0e17] flex flex-col justify-between transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      <div className="p-3 space-y-1">
        <div className="px-3 py-2 text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
          {!isCollapsed && 'Navigation'}
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectPage(item.id as NavigationPage)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-mono transition-all ${
                isActive
                  ? 'bg-cyan-500/15 text-cyan-300 font-bold border border-cyan-500/30 shadow-[0_0_12px_rgba(6,182,212,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
              title={item.label}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
              {!isCollapsed && (
                <span className="flex-1 text-left truncate">{item.label}</span>
              )}
              {!isCollapsed && item.badge && (
                <span className="text-[9px] px-1.5 py-0.2 rounded font-mono bg-slate-800 text-slate-400 border border-slate-700">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Sidebar Footer Info */}
      <div className="p-3 border-t border-slate-800/80">
        {!isCollapsed ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 text-[11px] font-mono text-slate-400 space-y-1">
            <div className="flex items-center justify-between text-slate-300">
              <span>EEG Dataset</span>
              <span className="font-bold text-cyan-400">CHB-MIT</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Sampling</span>
              <span>256 Hz</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Model Build</span>
              <span>v1.4-rc2</span>
            </div>
          </div>
        ) : (
          <div className="text-center font-mono text-[10px] text-cyan-400">v1.4</div>
        )}
      </div>
    </aside>
  );
};
