import React from 'react';
import { AppMode, Patient } from '@/src/types';
import { MOCK_PATIENTS } from '@/src/lib/mock/patients';
import { Brain, User, Activity, CheckCircle, Database, ChevronDown, Sparkles, Shield } from 'lucide-react';

interface TopBarProps {
  currentPatient: Patient;
  onSelectPatient: (patientId: string) => void;
  selectedRecordingId: string;
  onSelectRecording: (recordingId: string) => void;
  appMode: AppMode;
  onSelectAppMode: (mode: AppMode) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentPatient,
  onSelectPatient,
  selectedRecordingId,
  onSelectRecording,
  appMode,
  onSelectAppMode,
}) => {
  return (
    <header className="h-16 border-b border-slate-800 bg-[#0a0e17]/95 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between z-30 sticky top-0">
      {/* Brand & Title */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-cyan-400 p-0.5 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.4)]">
          <div className="w-full h-full bg-[#0a0e17] rounded-[10px] flex items-center justify-center">
            <Brain className="w-5 h-5 text-cyan-400" />
          </div>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono font-extrabold text-slate-100 tracking-tight text-base sm:text-lg">
              Neuro<span className="text-cyan-400">Pulse</span>
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800 text-cyan-300 font-semibold hidden md:inline">
              ACADEMIC PROTOTYPE
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono hidden lg:block -mt-0.5">
            Explainable EEG-Based Seizure Prediction & Brain-State Visualization
          </span>
        </div>
      </div>

      {/* Center Selectors: Patient, Recording, Dataset */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Patient selector */}
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs font-mono">
          <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <select
            value={currentPatient.id}
            onChange={(e) => onSelectPatient(e.target.value)}
            className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
          >
            {MOCK_PATIENTS.map((p) => (
              <option key={p.id} value={p.id} className="bg-slate-900 text-slate-200">
                {p.alias} ({p.diagnosis.substring(0, 18)}...)
              </option>
            ))}
          </select>
        </div>

        {/* Recording selector */}
        <div className="hidden md:flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs font-mono">
          <Database className="w-3.5 h-3.5 text-purple-400 shrink-0" />
          <select
            value={selectedRecordingId}
            onChange={(e) => onSelectRecording(e.target.value)}
            className="bg-transparent text-slate-200 focus:outline-none cursor-pointer"
          >
            {currentPatient.recordings.map((rec) => (
              <option key={rec.id} value={rec.id} className="bg-slate-900 text-slate-200">
                {rec.id} ({rec.type})
              </option>
            ))}
          </select>
        </div>

        {/* Model status indicator */}
        <div className="hidden xl:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] font-mono text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>Inference: <strong>14ms</strong></span>
          <span className="text-slate-500">•</span>
          <span>CHB-MIT Dataset</span>
        </div>
      </div>

      {/* Right Side: Mode Switcher (Patient / Clinical / Research) */}
      <div className="flex items-center gap-1 bg-slate-900/90 border border-slate-700/90 p-1 rounded-xl">
        {(['patient', 'clinical', 'research'] as AppMode[]).map((mode) => {
          const isActive = appMode === mode;
          return (
            <button
              key={mode}
              type="button"
              onClick={() => onSelectAppMode(mode)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono capitalize transition-all ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {mode}
            </button>
          );
        })}
      </div>
    </header>
  );
};
