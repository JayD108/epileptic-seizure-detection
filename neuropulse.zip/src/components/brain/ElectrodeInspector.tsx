import React from 'react';
import { Electrode } from '@/src/types';
import { ELECTRODES_10_20 } from '@/src/lib/mock/brain';
import { Activity, Zap, Radio, ShieldCheck, ArrowRight } from 'lucide-react';

interface ElectrodeInspectorProps {
  selectedElectrodeId: string | null;
  onSelectElectrode: (id: string | null) => void;
  onSelectAssociatedRegion: (regionId: string) => void;
}

export const ElectrodeInspector: React.FC<ElectrodeInspectorProps> = ({
  selectedElectrodeId,
  onSelectElectrode,
  onSelectAssociatedRegion,
}) => {
  const electrode = ELECTRODES_10_20.find((e) => e.id === selectedElectrodeId) || ELECTRODES_10_20.find((e) => e.id === 'T3')!;

  return (
    <div className="bg-[#111726]/90 border border-slate-800 rounded-xl p-4 backdrop-blur-md">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center font-mono font-bold text-cyan-300 text-sm">
            {electrode.name}
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              {electrode.fullName}
              {electrode.id === 'T3' || electrode.id === 'T5' ? (
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded">
                  Focal Lead
                </span>
              ) : null}
            </h4>
            <span className="text-xs text-slate-400 font-mono">10–20 Scalp Derivation</span>
          </div>
        </div>

        <select
          value={electrode.id}
          onChange={(e) => onSelectElectrode(e.target.value)}
          className="bg-slate-900 border border-slate-700 text-xs text-slate-300 rounded px-2.5 py-1.5 font-mono focus:outline-none focus:border-cyan-500"
        >
          {ELECTRODES_10_20.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name} — {e.fullName}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
        <div className="bg-slate-900/60 rounded-lg p-2.5 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
            <Activity className="w-3 h-3 text-cyan-400" />
            Activity
          </span>
          <span className="text-lg font-bold text-slate-100 font-mono mt-0.5 block">
            {Math.round(electrode.activityScore * 100)}%
          </span>
          <div className="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
            <div
              className={`h-full ${electrode.activityScore > 0.7 ? 'bg-rose-500' : electrode.activityScore > 0.4 ? 'bg-amber-400' : 'bg-cyan-400'}`}
              style={{ width: `${Math.round(electrode.activityScore * 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900/60 rounded-lg p-2.5 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
            <Zap className="w-3 h-3 text-amber-400" />
            Risk Contribution
          </span>
          <span className="text-lg font-bold text-amber-300 font-mono mt-0.5 block">
            {Math.round(electrode.riskContribution * 100)}%
          </span>
          <div className="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
            <div
              className="h-full bg-amber-400"
              style={{ width: `${Math.round(electrode.riskContribution * 100 * 2.5)}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900/60 rounded-lg p-2.5 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
            <Radio className="w-3 h-3 text-purple-400" />
            Dominant Band
          </span>
          <span className="text-base font-semibold text-purple-200 font-mono mt-0.5 block">
            {electrode.dominantBand}
          </span>
          <span className="text-[10px] text-slate-500 font-mono">
            {electrode.dominantBand === 'Theta' ? '4–8 Hz Slowing' : electrode.dominantBand === 'Alpha' ? '8–13 Hz PDR' : '13–30 Hz'}
          </span>
        </div>

        <div className="bg-slate-900/60 rounded-lg p-2.5 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            Impedance
          </span>
          <span className="text-base font-semibold text-emerald-300 font-mono mt-0.5 block">
            {electrode.impedanceKohm} kΩ
          </span>
          <span className="text-[10px] text-emerald-400/80 font-mono">
            Quality: {electrode.signalQuality}%
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs pt-1 text-slate-400">
        <span className="text-[11px]">
          Associated Cortical Region: <strong className="text-cyan-300 font-medium capitalize">{electrode.regionId.replace('_', ' ')}</strong>
        </span>
        <button
          type="button"
          onClick={() => onSelectAssociatedRegion(electrode.regionId)}
          className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 text-[11px] font-medium transition-colors"
        >
          <span>Highlight Region in 3D</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
