import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  ANATOMICAL_LOBES,
  createAnatomicalHemisphereGeometry,
  createAnatomicalCerebellumGeometry,
  createAnatomicalBrainstemGeometry,
  createSubcorticalStructuresGroup,
} from './AnatomicalBrainMesh';
import { ELECTRODES_10_20, BRAIN_REGIONS } from '@/src/lib/mock/brain';
import {
  RotateCcw,
  Sparkles,
  Layers,
  ArrowRight,
  Activity,
  Radio,
  Eye,
  Sliders,
  Maximize2,
  Zap,
} from 'lucide-react';

export type BrainViewMode = 'activity' | 'anatomy' | 'deep';
export type ViewingPlane = '3d' | 'sagittal' | 'coronal' | 'axial';

interface BrainActivityStudioProps {
  selectedElectrodeId: string | null;
  onSelectElectrode: (electrodeId: string | null) => void;
  selectedRegionId: string | null;
  onSelectRegion: (regionId: string | null) => void;
  preictalSeverity?: number;
  onNavigateToEEG?: (channelId: string) => void;
  className?: string;
}

export const BrainActivityStudio: React.FC<BrainActivityStudioProps> = ({
  selectedElectrodeId = 'T3',
  onSelectElectrode,
  selectedRegionId = 'left_temporal',
  onSelectRegion,
  preictalSeverity = 0.73,
  onNavigateToEEG,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const brainRootRef = useRef<THREE.Group | null>(null);
  const lobesGroupRef = useRef<THREE.Group | null>(null);
  const subcorticalGroupRef = useRef<THREE.Group | null>(null);
  const electrodesGroupRef = useRef<THREE.Group | null>(null);
  const clipPlaneRef = useRef<THREE.Plane | null>(null);
  const animIdRef = useRef<number | null>(null);

  // Studio Controls State
  const [viewMode, setViewMode] = useState<BrainViewMode>('activity');
  const [cortexOpacity, setCortexOpacity] = useState<number>(0.92);
  const [viewingPlane, setViewingPlane] = useState<ViewingPlane>('3d');
  const [sliceDepth, setSliceDepth] = useState<number>(0);
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(false);
  const [hemisphereFilter, setHemisphereFilter] = useState<'both' | 'left' | 'right'>('both');

  // Mini live EEG waveform simulation for right panel
  const [miniWaveOffset, setMiniWaveOffset] = useState<number>(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMiniWaveOffset((prev) => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  // Compute active region metadata
  const activeRegion =
    BRAIN_REGIONS.find((r) => r.id === selectedRegionId) ||
    BRAIN_REGIONS.find((r) => r.id === 'left_temporal') ||
    BRAIN_REGIONS[0];

  const activeElectrode =
    ELECTRODES_10_20.find((e) => e.id === selectedElectrodeId) ||
    ELECTRODES_10_20.find((e) => e.id === 'T3') ||
    ELECTRODES_10_20[0];

  // Associated channels for right panel
  const associatedChannels =
    activeRegion.associatedChannels.length > 0 ? activeRegion.associatedChannels : ['T3', 'T5'];

  // Initialize Three.js Anatomical Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x070a12, 0.09);

    // Camera
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 4.6);
    cameraRef.current = camera;

    // Renderer with Local Clipping Support
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.localClippingEnabled = true;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x334155, 1.4);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x67e8f9, 2.4); // Cyan key
    keyLight.position.set(4, 5, 4);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x818cf8, 1.6); // Indigo fill
    fillLight.position.set(-4, -2, -3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf43f5e, 1.9); // Ruby/coral rim
    rimLight.position.set(0, 4, -4);
    scene.add(rimLight);

    // Root Group
    const brainRoot = new THREE.Group();
    scene.add(brainRoot);
    brainRootRef.current = brainRoot;

    // Clipping Plane
    const clipPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 10);
    clipPlaneRef.current = clipPlane;

    // Lobes Group
    const lobesGroup = new THREE.Group();
    lobesGroup.name = 'lobesGroup';
    brainRoot.add(lobesGroup);
    lobesGroupRef.current = lobesGroup;

    // Build Left Hemisphere
    const leftHemisphereGeom = createAnatomicalHemisphereGeometry(true);
    const leftMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.38,
      metalness: 0.15,
      transparent: true,
      opacity: cortexOpacity,
      clippingPlanes: [],
      clipShadows: true,
    });
    const leftHemiMesh = new THREE.Mesh(leftHemisphereGeom, leftMat);
    leftHemiMesh.userData = { id: 'left_hemisphere', hemisphere: 'left' };
    lobesGroup.add(leftHemiMesh);

    // Build Right Hemisphere
    const rightHemisphereGeom = createAnatomicalHemisphereGeometry(false);
    const rightMat = leftMat.clone();
    const rightHemiMesh = new THREE.Mesh(rightHemisphereGeom, rightMat);
    rightHemiMesh.userData = { id: 'right_hemisphere', hemisphere: 'right' };
    lobesGroup.add(rightHemiMesh);

    // Build Cerebellum
    const cerebellumGeom = createAnatomicalCerebellumGeometry();
    const cerebellumMat = new THREE.MeshStandardMaterial({
      color: 0x0f766e,
      roughness: 0.45,
      metalness: 0.1,
      transparent: true,
      opacity: cortexOpacity,
      clippingPlanes: [],
    });
    const cerebellumMesh = new THREE.Mesh(cerebellumGeom, cerebellumMat);
    cerebellumMesh.userData = { id: 'cerebellum', hemisphere: 'both' };
    lobesGroup.add(cerebellumMesh);

    // Build Brainstem
    const brainstemGeom = createAnatomicalBrainstemGeometry();
    const brainstemMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.5,
      metalness: 0.1,
      transparent: true,
      opacity: cortexOpacity,
      clippingPlanes: [],
    });
    const brainstemMesh = new THREE.Mesh(brainstemGeom, brainstemMat);
    brainstemMesh.userData = { id: 'brainstem', hemisphere: 'both' };
    lobesGroup.add(brainstemMesh);

    // Build Deep Subcortical Structures (Hippocampi, Thalami, Corpus Callosum)
    const subcorticalGroup = createSubcorticalStructuresGroup();
    brainRoot.add(subcorticalGroup);
    subcorticalGroupRef.current = subcorticalGroup;

    // Electrodes Group
    const electrodesGroup = new THREE.Group();
    electrodesGroup.name = 'electrodesGroup';
    brainRoot.add(electrodesGroup);
    electrodesGroupRef.current = electrodesGroup;

    // Add 10-20 Scalp Electrodes
    ELECTRODES_10_20.forEach((elec) => {
      const elecGroup = new THREE.Group();
      elecGroup.position.set(elec.coords[0] * 1.15, elec.coords[1] * 1.15, elec.coords[2] * 1.15);

      const sphereGeom = new THREE.SphereGeometry(0.045, 16, 16);
      const isFocal = elec.id === 'T3' || elec.id === 'T5';
      const sphereMat = new THREE.MeshStandardMaterial({
        color: isFocal ? 0xf43f5e : 0x38bdf8,
        emissive: isFocal ? 0xf43f5e : 0x0284c7,
        emissiveIntensity: isFocal ? 0.9 : 0.4,
        roughness: 0.2,
        metalness: 0.8,
      });
      const sphereMesh = new THREE.Mesh(sphereGeom, sphereMat);
      sphereMesh.userData = { electrodeId: elec.id, type: 'electrode' };
      elecGroup.add(sphereMesh);

      // Outer Halo Ring
      const ringGeom = new THREE.RingGeometry(0.06, 0.08, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: isFocal ? 0xf43f5e : 0x38bdf8,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7,
      });
      const ringMesh = new THREE.Mesh(ringGeom, ringMat);
      ringMesh.lookAt(new THREE.Vector3(0, 0, 0));
      ringMesh.userData = { isRing: true, electrodeId: elec.id };
      elecGroup.add(ringMesh);

      elecGroup.userData = { electrodeId: elec.id, type: 'electrode' };
      electrodesGroup.add(elecGroup);
    });

    // Mouse Interaction (Orbiting & Raycasting)
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let targetRotationX = 0.2;
    let targetRotationY = -0.4;
    let currentRotationX = 0.2;
    let currentRotationY = -0.4;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const deltaX = e.clientX - prevMouseX;
        const deltaY = e.clientY - prevMouseY;
        targetRotationY += deltaX * 0.008;
        targetRotationX += deltaY * 0.008;
        targetRotationX = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, targetRotationX));
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (!isDragging) return;
      isDragging = false;

      // Raycast click if mouse barely moved
      const rect = renderer.domElement.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, camera);

      const intersects = raycaster.intersectObjects(brainRoot.children, true);
      for (const hit of intersects) {
        if (hit.object.userData?.electrodeId) {
          onSelectElectrode(hit.object.userData.electrodeId);
          return;
        }
      }
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z += e.deltaY * 0.003;
      camera.position.z = Math.max(2.8, Math.min(7.5, camera.position.z));
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    domEl.addEventListener('wheel', onWheel, { passive: false });

    // Render Loop
    let clock = new THREE.Clock();

    const animate = () => {
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      if (isAutoRotating && !isDragging) {
        targetRotationY += delta * 0.45;
      }

      currentRotationX += (targetRotationX - currentRotationX) * 0.1;
      currentRotationY += (targetRotationY - currentRotationY) * 0.1;

      brainRoot.rotation.x = currentRotationX;
      brainRoot.rotation.y = currentRotationY;

      // Pulse active electrodes & halos
      electrodesGroup.children.forEach((group: any) => {
        const elecId = group.userData?.electrodeId;
        const isSelected = elecId === selectedElectrodeId;
        const isFocal = elecId === 'T3' || elecId === 'T5';

        const scale = isSelected ? 1.3 + Math.sin(time * 6) * 0.25 : isFocal ? 1.1 + Math.sin(time * 4) * 0.15 : 1.0;
        group.scale.set(scale, scale, scale);
      });

      renderer.render(scene, camera);
      animIdRef.current = requestAnimationFrame(animate);
    };

    animIdRef.current = requestAnimationFrame(animate);

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          camera.aspect = width / height;
          camera.updateProjectionMatrix();
          renderer.setSize(width, height);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      if (animIdRef.current) cancelAnimationFrame(animIdRef.current);
      resizeObserver.disconnect();
      domEl.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      domEl.removeEventListener('wheel', onWheel);
      renderer.dispose();
    };
  }, []);

  // Update Materials based on View Mode (Activity / Anatomy / Deep View) & Opacity
  useEffect(() => {
    if (!lobesGroupRef.current || !subcorticalGroupRef.current) return;

    const isDeep = viewMode === 'deep';
    const isAnatomy = viewMode === 'anatomy';
    const isActivity = viewMode === 'activity';

    // In Deep View, cortex is made translucent to reveal hippocampus and thalamus
    const effectiveOpacity = isDeep ? 0.22 : cortexOpacity;

    lobesGroupRef.current.children.forEach((mesh: any) => {
      if (!mesh.material) return;
      mesh.material.transparent = true;
      mesh.material.opacity = effectiveOpacity;

      const hemi = mesh.userData.hemisphere;
      // Hemisphere filtering
      mesh.visible =
        hemisphereFilter === 'both' ||
        hemi === 'both' ||
        hemi === hemisphereFilter;

      if (isActivity) {
        // Activity View: Left temporal area is highlighted with elevated preictal glow
        const isLeft = mesh.userData.id === 'left_hemisphere';
        if (isLeft && (selectedRegionId === 'left_temporal' || selectedElectrodeId === 'T3' || selectedElectrodeId === 'T5')) {
          mesh.material.color.setHex(0xf43f5e); // Rose / Coral active
          mesh.material.emissive.setHex(0xf43f5e);
          mesh.material.emissiveIntensity = 0.45;
        } else {
          mesh.material.color.setHex(0x1e293b); // Baseline slate
          mesh.material.emissive.setHex(0x082f49);
          mesh.material.emissiveIntensity = 0.15;
        }
      } else if (isAnatomy) {
        // Anatomical Atlas: Distinct scientific colors
        if (mesh.userData.id === 'left_hemisphere') {
          mesh.material.color.setHex(0x38bdf8); // Cyan/Azure
          mesh.material.emissive.setHex(0x0284c7);
          mesh.material.emissiveIntensity = 0.2;
        } else if (mesh.userData.id === 'right_hemisphere') {
          mesh.material.color.setHex(0x818cf8); // Indigo
          mesh.material.emissive.setHex(0x4338ca);
          mesh.material.emissiveIntensity = 0.2;
        } else if (mesh.userData.id === 'cerebellum') {
          mesh.material.color.setHex(0x14b8a6); // Teal
          mesh.material.emissive.setHex(0x0f766e);
          mesh.material.emissiveIntensity = 0.2;
        } else if (mesh.userData.id === 'brainstem') {
          mesh.material.color.setHex(0x94a3b8); // Slate
          mesh.material.emissive.setHex(0x475569);
          mesh.material.emissiveIntensity = 0.1;
        }
      } else if (isDeep) {
        // Deep View: Subdued dark translucent cortex
        mesh.material.color.setHex(0x0f172a);
        mesh.material.emissive.setHex(0x000000);
        mesh.material.emissiveIntensity = 0;
      }
    });

    // Subcortical structures visibility
    subcorticalGroupRef.current.visible = isDeep || cortexOpacity < 0.6;
  }, [viewMode, cortexOpacity, selectedRegionId, selectedElectrodeId, hemisphereFilter]);

  // Update Viewing Plane & Clipping (3D / Sagittal / Coronal / Axial)
  useEffect(() => {
    if (!rendererRef.current || !cameraRef.current || !brainRootRef.current) return;

    const renderer = rendererRef.current;
    const camera = cameraRef.current;
    const brainRoot = brainRootRef.current;

    let plane: THREE.Plane | null = null;

    if (viewingPlane === '3d') {
      renderer.clippingPlanes = [];
      // Free 3D view
    } else if (viewingPlane === 'sagittal') {
      // Side cross-section along X axis
      plane = new THREE.Plane(new THREE.Vector3(1, 0, 0), sliceDepth);
      renderer.clippingPlanes = [plane];
      camera.position.set(4.4, 0.2, 0);
      camera.lookAt(0, 0, 0);
      brainRoot.rotation.set(0, 0, 0);
    } else if (viewingPlane === 'coronal') {
      // Frontal cross-section along Z axis
      plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), sliceDepth);
      renderer.clippingPlanes = [plane];
      camera.position.set(0, 0.2, 4.4);
      camera.lookAt(0, 0, 0);
      brainRoot.rotation.set(0, 0, 0);
    } else if (viewingPlane === 'axial') {
      // Horizontal cross-section along Y axis
      plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), sliceDepth);
      renderer.clippingPlanes = [plane];
      camera.position.set(0, 4.6, 0.05);
      camera.lookAt(0, 0, 0);
      brainRoot.rotation.set(0, 0, 0);
    }

    // Apply clipping planes to all mesh materials
    if (lobesGroupRef.current) {
      lobesGroupRef.current.children.forEach((mesh: any) => {
        if (mesh.material) {
          mesh.material.clippingPlanes = renderer.clippingPlanes;
          mesh.material.needsUpdate = true;
        }
      });
    }
  }, [viewingPlane, sliceDepth]);

  // Camera Reset
  const handleResetCamera = () => {
    if (!cameraRef.current || !brainRootRef.current) return;
    cameraRef.current.position.set(0, 1.2, 4.6);
    cameraRef.current.lookAt(0, 0, 0);
    brainRootRef.current.rotation.set(0.2, -0.4, 0);
    setViewingPlane('3d');
  };

  return (
    <div className={`bg-[#0a0e17] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col ${className}`}>
      {/* Studio Header */}
      <div className="h-12 border-b border-slate-800/80 px-4 flex items-center justify-between bg-[#0e1320]">
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-cyan-400 font-bold uppercase tracking-wider">NeuroPulse</span>
          <span className="text-slate-500">/</span>
          <span className="text-slate-200 font-semibold">Brain Activity Studio</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800/80 text-cyan-300 ml-2">
            Anatomical Cortical Atlas
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Auto rotate toggle */}
          <button
            type="button"
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`px-2 py-1 rounded text-xs font-mono transition-colors ${
              isAutoRotating ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-slate-900 text-slate-400 border border-slate-800'
            }`}
          >
            {isAutoRotating ? 'Rotating ↺' : 'Rotate'}
          </button>

          {/* Reset Camera */}
          <button
            type="button"
            onClick={handleResetCamera}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-300 transition-colors"
            title="Reset 3D View Camera"
          >
            <RotateCcw className="w-3 h-3 text-cyan-400" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* 3-Column Layout: Left Controls | Center 3D Viewport | Right Region & EEG Inspection */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[580px] divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
        {/* LEFT COLUMN: VIEW, OPACITY & PLANES CONTROLS (3 cols) */}
        <div className="lg:col-span-3 p-4 bg-[#090d15] flex flex-col justify-between space-y-5 font-mono text-xs">
          <div className="space-y-5">
            {/* VIEW MODE SELECTOR */}
            <div>
              <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-2">
                VIEW
              </span>
              <div className="space-y-1.5">
                {(
                  [
                    { id: 'activity', label: 'Activity', desc: 'Preictal focal heat activation' },
                    { id: 'anatomy', label: 'Anatomy', desc: 'Cortical lobe atlas boundaries' },
                    { id: 'deep', label: 'Deep View', desc: 'Hippocampus & subcortical nuclei' },
                  ] as const
                ).map((mode) => {
                  const isSelected = viewMode === mode.id;
                  return (
                    <button
                      key={mode.id}
                      type="button"
                      onClick={() => setViewMode(mode.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-lg border text-left transition-all ${
                        isSelected
                          ? 'bg-cyan-950/40 border-cyan-500/60 text-cyan-200'
                          : 'bg-slate-900/40 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            isSelected ? 'bg-cyan-400 ring-2 ring-cyan-500/30' : 'bg-slate-600'
                          }`}
                        />
                        <span className="font-bold text-xs">{mode.label}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{mode.desc.split(' ')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* CORTEX OPACITY SLIDER */}
            <div className="pt-3 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-[11px] text-slate-300 mb-1.5">
                <span className="font-bold uppercase tracking-wider">Cortex Opacity</span>
                <span className="text-cyan-400 font-bold">{Math.round(cortexOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={cortexOpacity}
                onChange={(e) => setCortexOpacity(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-slate-500 mt-1">
                <span>Translucent (Subcortical)</span>
                <span>Solid Cortex</span>
              </div>
            </div>

            {/* VIEWING PLANES */}
            <div className="pt-3 border-t border-slate-800/80">
              <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-2">
                Planes
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                {(['3d', 'sagittal', 'coronal', 'axial'] as const).map((plane) => {
                  const isSelected = viewingPlane === plane;
                  return (
                    <button
                      key={plane}
                      type="button"
                      onClick={() => setViewingPlane(plane)}
                      className={`px-3 py-2 rounded-lg border text-center uppercase font-bold text-xs transition-all ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20'
                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {plane === '3d' ? '3D' : plane}
                    </button>
                  );
                })}
              </div>

              {/* Slice Depth Slider (Active in 2D planes) */}
              {viewingPlane !== '3d' && (
                <div className="mt-3 p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span>Slice Cross-Section:</span>
                    <span className="text-cyan-300 font-bold">{sliceDepth.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="-1.2"
                    max="1.2"
                    step="0.05"
                    value={sliceDepth}
                    onChange={(e) => setSliceDepth(parseFloat(e.target.value))}
                    className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
                  />
                </div>
              )}
            </div>

            {/* HEMISPHERE TOGGLE */}
            <div className="pt-3 border-t border-slate-800/80">
              <span className="text-[10px] text-slate-400 block mb-1.5 uppercase">Hemisphere</span>
              <div className="flex rounded-lg bg-slate-900 border border-slate-800 p-0.5">
                {(['both', 'left', 'right'] as const).map((hemi) => (
                  <button
                    key={hemi}
                    type="button"
                    onClick={() => setHemisphereFilter(hemi)}
                    className={`flex-1 py-1 text-[10px] rounded uppercase font-bold transition-colors ${
                      hemisphereFilter === hemi ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400'
                    }`}
                  >
                    {hemi}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-slate-900/40 rounded border border-slate-800/80 text-[10px] text-slate-500 leading-tight">
            Click any electrode or anatomical lobe in 3D to synchronize EEG traces and feature contributions.
          </div>
        </div>

        {/* CENTER COLUMN: REAL ANATOMICAL CORTICAL BRAIN VIEWPORT (6 cols) */}
        <div className="lg:col-span-6 relative bg-[#070a12] flex items-center justify-center min-h-[460px]">
          <div ref={containerRef} className="w-full h-full min-h-[460px] cursor-grab active:cursor-grabbing" />

          {/* Floating HUD Badges */}
          <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-slate-900/80 backdrop-blur-md border border-slate-800 text-[11px] font-mono text-slate-300 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span>Focal Activation: <strong>Left Temporal (T3 · T5)</strong></span>
          </div>

          <div className="absolute bottom-3 left-3 text-[10px] font-mono text-slate-500">
            10–20 Scalp Derivations • Drag to Orbit • Scroll to Zoom
          </div>
        </div>

        {/* RIGHT COLUMN: REGION & ASSOCIATED EEG INSPECTOR (3 cols) */}
        <div className="lg:col-span-3 p-4 bg-[#090d15] flex flex-col justify-between space-y-4 font-mono text-xs">
          <div className="space-y-4">
            {/* REGION TITLE & LEADS */}
            <div className="border-b border-slate-800/80 pb-3">
              <span className="text-[10px] text-slate-400 uppercase tracking-widest block mb-0.5">
                Cortical Locus
              </span>
              <h3 className="text-base font-bold text-slate-100 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                {activeRegion.name}
              </h3>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-slate-400 text-xs">Leads:</span>
                <span className="px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 text-cyan-300 font-bold text-xs">
                  {associatedChannels.join(' · ')}
                </span>
              </div>
            </div>

            {/* METRICS: Activity %, Risk %, Dominant Band */}
            <div className="space-y-2.5">
              <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400 text-[11px] flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  Activity
                </span>
                <span className="text-sm font-bold text-slate-100">
                  {Math.round(activeRegion.activityScore * 100)}%
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400 text-[11px] flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  Risk Contribution
                </span>
                <span className="text-sm font-bold text-amber-300">
                  {Math.round(activeRegion.riskContribution * 100)}%
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400 text-[11px] flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-purple-400" />
                  Dominant Band
                </span>
                <span className="text-sm font-bold text-purple-300">
                  {activeRegion.dominantBands[0] || 'Theta 4–8Hz'}
                </span>
              </div>
            </div>

            {/* DIVIDER */}
            <div className="border-t border-slate-800/80 pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  Associated EEG
                </span>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-1.5 rounded">
                  Live Sync
                </span>
              </div>

              {/* MINI LIVE EEG WAVEFORM PREVIEW FOR ASSOCIATED LEADS */}
              <div className="space-y-2 bg-[#060910] border border-slate-800/90 rounded-lg p-2.5">
                {associatedChannels.slice(0, 2).map((ch) => {
                  return (
                    <div key={ch} className="space-y-0.5">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-cyan-300">{ch}</span>
                        <span className="text-slate-500 font-mono">256 Hz • Preictal</span>
                      </div>
                      {/* SVG Mini Waveform */}
                      <svg className="w-full h-8 overflow-hidden bg-slate-950/60 rounded" viewBox="0 0 100 24">
                        <path
                          d={Array.from({ length: 25 })
                            .map((_, i) => {
                              const x = (i / 24) * 100;
                              // Simulated rhythmic 5 Hz theta oscillations
                              const angle = (i + miniWaveOffset * 0.4) * 0.7;
                              const y = 12 + Math.sin(angle) * 7 + Math.sin(angle * 2.3) * 2;
                              return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
                            })
                            .join(' ')}
                          fill="none"
                          stroke={ch === 'T3' ? '#38bdf8' : '#f43f5e'}
                          strokeWidth="1.2"
                        />
                      </svg>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ACTION BUTTON: [View EEG →] */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => onNavigateToEEG?.(associatedChannels[0] || 'T3')}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-xl transition-all shadow-lg shadow-cyan-600/20 text-xs uppercase tracking-wide"
            >
              <span>View EEG Waveform →</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
