import React from 'react';
import { BrainRegionActivity } from '@/src/types';
import { BRAIN_REGIONS } from '@/src/lib/mock/brain';
import { AlertCircle, ChevronRight, Activity, Zap } from 'lucide-react';

interface RegionalActivityListProps {
  selectedRegionId: string | null;
  onSelectRegion: (id: string | null) => void;
  onSelectElectrode: (channelId: string) => void;
}

export const RegionalActivityList: React.FC<RegionalActivityListProps> = ({
  selectedRegionId,
  onSelectRegion,
  onSelectElectrode,
}) => {
  return (
    <div className="bg-[#111726]/90 border border-slate-800 rounded-xl p-4 backdrop-blur-md">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <span>Regional EEG Activity Estimates</span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/60 text-cyan-300">
              Scalp Association
            </span>
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Cortical lobe projections derived from 10–20 electrode spectral power mapping.
          </p>
        </div>
      </div>

      <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
        {BRAIN_REGIONS.map((region) => {
          const isSelected = selectedRegionId === region.id;
          const isElevated = region.activityScore >= 0.7;
          const isModerate = region.activityScore >= 0.4 && region.activityScore < 0.7;

          return (
            <div
              key={region.id}
              onClick={() => onSelectRegion(isSelected ? null : region.id)}
              className={`p-3 rounded-lg border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-cyan-950/40 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                  : isElevated
                  ? 'bg-rose-950/20 border-rose-800/40 hover:border-rose-700/60'
                  : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-900/80 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      isElevated ? 'bg-rose-500 animate-pulse' : isModerate ? 'bg-amber-400' : 'bg-cyan-400'
                    }`}
                  />
                  <span className="font-medium text-xs text-slate-100">{region.name}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                      isElevated
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : isModerate
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isElevated ? 'Elevated' : isModerate ? 'Moderate' : 'Baseline'}
                  </span>
                  <ChevronRight className={`w-3.5 h-3.5 text-slate-500 transition-transform ${isSelected ? 'rotate-90 text-cyan-400' : ''}`} />
                </div>
              </div>

              {/* Activity & Contribution Meters */}
              <div className="grid grid-cols-2 gap-3 my-2 text-[11px] font-mono">
                <div>
                  <div className="flex justify-between text-slate-400 mb-0.5">
                    <span>Activity Score</span>
                    <span className="text-slate-200 font-bold">{Math.round(region.activityScore * 100)}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${isElevated ? 'bg-rose-500' : isModerate ? 'bg-amber-400' : 'bg-cyan-400'}`}
                      style={{ width: `${Math.round(region.activityScore * 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-0.5">
                    <span>Risk Contribution</span>
                    <span className="text-amber-300 font-bold">{Math.round(region.riskContribution * 100)}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-400"
                      style={{ width: `${Math.round(region.riskContribution * 100 * 2.2)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Channels & dominant band chips */}
              <div className="flex flex-wrap items-center gap-1.5 mt-2 pt-2 border-t border-slate-800/60">
                <span className="text-[10px] text-slate-400">Associated Leads:</span>
                {region.associatedChannels.map((ch) => (
                  <button
                    key={ch}
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectElectrode(ch);
                    }}
                    className="px-1.5 py-0.5 text-[10px] font-mono rounded bg-slate-800 hover:bg-cyan-900/60 text-cyan-300 hover:border-cyan-500/50 border border-slate-700/60 transition-colors"
                    title={`Click to inspect channel ${ch} in EEG Viewer`}
                  >
                    {ch}
                  </button>
                ))}
                <span className="text-[10px] text-slate-500 ml-auto font-mono">
                  {region.dominantBands[0]}
                </span>
              </div>

              {isSelected && (
                <div className="mt-2.5 pt-2 border-t border-cyan-900/40 text-[11px] text-slate-300 leading-relaxed bg-cyan-950/20 p-2 rounded">
                  <div className="flex items-start gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                    <p>{region.description}</p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
