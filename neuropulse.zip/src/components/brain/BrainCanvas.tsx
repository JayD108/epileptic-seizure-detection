import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { BrainRegionActivity, Electrode } from '@/src/types';
import { BRAIN_REGIONS, ELECTRODES_10_20 } from '@/src/lib/mock/brain';
import {
  createAnatomicalHemisphereGeometry,
  createAnatomicalCerebellumGeometry,
  createAnatomicalBrainstemGeometry,
} from './AnatomicalBrainMesh';
import { Eye, RotateCcw, ZoomIn, ZoomOut, Layers, Sparkles, AlertTriangle } from 'lucide-react';

interface BrainCanvasProps {
  selectedRegionId: string | null;
  onSelectRegion: (regionId: string | null) => void;
  selectedElectrodeId: string | null;
  onSelectElectrode: (electrodeId: string | null) => void;
  preictalSeverity?: number; // 0 to 1
  className?: string;
  hemisphereFilter?: 'both' | 'left' | 'right';
}

export const BrainCanvas: React.FC<BrainCanvasProps> = ({
  selectedRegionId,
  onSelectRegion,
  selectedElectrodeId,
  onSelectElectrode,
  preictalSeverity = 0.73,
  className = '',
  hemisphereFilter = 'both',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const brainGroupRef = useRef<THREE.Group | null>(null);
  const electrodesGroupRef = useRef<THREE.Group | null>(null);
  const reqIdRef = useRef<number | null>(null);

  const [hoveredItem, setHoveredItem] = useState<{
    type: 'region' | 'electrode';
    name: string;
    details: string;
    score: number;
    risk: number;
    band?: string;
    screenX: number;
    screenY: number;
  } | null>(null);

  const [viewAngle, setViewAngle] = useState<'default' | 'top' | 'left' | 'right' | 'front'>('default');
  const [showElectrodes, setShowElectrodes] = useState<boolean>(true);
  const [showGyriWireframe, setShowGyriWireframe] = useState<boolean>(false);
  const [localHemisphere, setLocalHemisphere] = useState<'both' | 'left' | 'right'>(hemisphereFilter);

  // Sync prop changes
  useEffect(() => {
    setLocalHemisphere(hemisphereFilter);
  }, [hemisphereFilter]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // SCENE SETUP
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x0b0f17, 0.12);

    // CAMERA
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.8, 4.4);
    cameraRef.current = camera;

    // RENDERER
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // LIGHTING
    const ambientLight = new THREE.AmbientLight(0x2d3748, 1.5);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x67e8f9, 2.2); // Cyan key
    keyLight.position.set(4, 5, 4);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x818cf8, 1.4); // Indigo fill
    fillLight.position.set(-4, -2, -3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf43f5e, 1.8); // Coral/Ruby rim
    rimLight.position.set(0, 4, -4);
    scene.add(rimLight);

    // ROOT BRAIN GROUP
    const brainRoot = new THREE.Group();
    scene.add(brainRoot);
    brainGroupRef.current = brainRoot;

    // REAL ANATOMICAL CORTICAL GEOMETRY
    // Build left & right hemispheres with anatomically authentic frontal, temporal, and occipital morphology
    const createHemisphere = (isLeft: boolean) => {
      const hemiGroup = new THREE.Group();
      hemiGroup.name = isLeft ? 'hemi_left' : 'hemi_right';

      const geo = createAnatomicalHemisphereGeometry(isLeft);

      // Material with sub-surface scattering vibe
      const mat = new THREE.MeshPhysicalMaterial({
        color: isLeft ? 0x223549 : 0x1e2e42,
        roughness: 0.35,
        metalness: 0.15,
        clearcoat: 0.4,
        clearcoatRoughness: 0.2,
        wireframe: false,
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.name = isLeft ? 'mesh_left' : 'mesh_right';
      mesh.castShadow = true;
      hemiGroup.add(mesh);

      // Wireframe overlay for technical scientific scan feeling
      const wireMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        wireframe: true,
        transparent: true,
        opacity: 0.08,
      });
      const wireMesh = new THREE.Mesh(geo.clone(), wireMat);
      wireMesh.scale.set(1.002, 1.002, 1.002);
      wireMesh.name = isLeft ? 'wire_left' : 'wire_right';
      hemiGroup.add(wireMesh);

      return hemiGroup;
    };

    const leftHemi = createHemisphere(true);
    const rightHemi = createHemisphere(false);
    brainRoot.add(leftHemi);
    brainRoot.add(rightHemi);

    // Add Infratentorial Cerebellum
    const cerebellumGeom = createAnatomicalCerebellumGeometry();
    const cerebellumMat = new THREE.MeshPhysicalMaterial({
      color: 0x0f766e,
      roughness: 0.45,
      metalness: 0.1,
    });
    const cerebellumMesh = new THREE.Mesh(cerebellumGeom, cerebellumMat);
    cerebellumMesh.name = 'cerebellum';
    brainRoot.add(cerebellumMesh);

    // Add Brainstem
    const brainstemGeom = createAnatomicalBrainstemGeometry();
    const brainstemMat = new THREE.MeshPhysicalMaterial({
      color: 0x475569,
      roughness: 0.5,
      metalness: 0.1,
    });
    const brainstemMesh = new THREE.Mesh(brainstemGeom, brainstemMat);
    brainstemMesh.name = 'brainstem';
    brainRoot.add(brainstemMesh);

    // REGIONAL ACTIVITY HIGHLIGHT VOLUMES
    // Sub-volumes positioned at cortical lobes for spatial heat mapping
    BRAIN_REGIONS.forEach((region) => {
      const regionGeo = new THREE.SphereGeometry(0.55, 24, 24);
      const isLeft = region.id.includes('left');
      const isTemporal = region.id.includes('temporal');

      // Activity color gradient: baseline teal -> amber -> warning coral/crimson
      let heatColor = 0x06b6d4; // cyan
      if (region.activityScore > 0.7) heatColor = 0xf43f5e; // rose/coral
      else if (region.activityScore > 0.4) heatColor = 0xf59e0b; // amber

      const regionMat = new THREE.MeshStandardMaterial({
        color: heatColor,
        emissive: heatColor,
        emissiveIntensity: region.activityScore * 1.6,
        transparent: true,
        opacity: Math.max(0.2, region.activityScore * 0.7),
        roughness: 0.2,
      });

      const regionMesh = new THREE.Mesh(regionGeo, regionMat);
      regionMesh.position.set(region.coords[0] * 0.75, region.coords[1] * 0.75, region.coords[2] * 0.75);
      regionMesh.userData = { regionId: region.id, isRegionVolume: true };
      regionMesh.name = `region_vol_${region.id}`;

      // Scale to match lobe shape
      if (isTemporal) {
        regionMesh.scale.set(1.2, 0.7, 1.4);
      } else if (region.id.includes('frontal')) {
        regionMesh.scale.set(1.1, 0.9, 1.3);
      } else {
        regionMesh.scale.set(1.0, 1.0, 1.0);
      }

      brainRoot.add(regionMesh);
    });

    // 10-20 ELECTRODES OVERLAY
    const electrodesGroup = new THREE.Group();
    electrodesGroup.name = 'electrodes_group';
    brainRoot.add(electrodesGroup);
    electrodesGroupRef.current = electrodesGroup;

    ELECTRODES_10_20.forEach((elec) => {
      const elecPivot = new THREE.Group();
      elecPivot.position.set(elec.coords[0] * 0.88, elec.coords[1] * 0.88, elec.coords[2] * 0.88);

      const isFocal = elec.id === 'T3' || elec.id === 'T5';
      const elecColor = isFocal && preictalSeverity > 0.5 ? 0xf43f5e : elec.activityScore > 0.5 ? 0xf59e0b : 0x38bdf8;

      // Inner electrode bead
      const beadGeo = new THREE.SphereGeometry(0.045, 16, 16);
      const beadMat = new THREE.MeshStandardMaterial({
        color: elecColor,
        emissive: elecColor,
        emissiveIntensity: isFocal ? 1.4 : 0.8,
        roughness: 0.2,
      });
      const bead = new THREE.Mesh(beadGeo, beadMat);
      bead.userData = { electrodeId: elec.id, isElectrode: true };
      elecPivot.add(bead);

      // Outer pulsing halo ring
      const ringGeo = new THREE.RingGeometry(0.065, 0.08, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: elecColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: isFocal ? 0.75 : 0.35,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.lookAt(elecPivot.position.clone().multiplyScalar(2));
      ring.userData = { isRing: true, isFocal };
      elecPivot.add(ring);

      elecPivot.name = `electrode_${elec.id}`;
      electrodesGroup.add(elecPivot);
    });

    // CRANIAL COORDINATE ORBITS / CALIBRATION GRID
    const gridCircleMat = new THREE.LineBasicMaterial({ color: 0x1e293b, transparent: true, opacity: 0.45 });
    const createOrbit = (radius: number, axis: 'x' | 'y' | 'z') => {
      const pts = [];
      for (let a = 0; a <= 64; a++) {
        const theta = (a / 64) * Math.PI * 2;
        if (axis === 'y') pts.push(new THREE.Vector3(Math.cos(theta) * radius, 0, Math.sin(theta) * radius * 1.15));
        else if (axis === 'z') pts.push(new THREE.Vector3(Math.cos(theta) * radius * 0.9, Math.sin(theta) * radius, 0));
        else pts.push(new THREE.Vector3(0, Math.cos(theta) * radius, Math.sin(theta) * radius * 1.15));
      }
      const orbitGeo = new THREE.BufferGeometry().setFromPoints(pts);
      return new THREE.Line(orbitGeo, gridCircleMat);
    };
    brainRoot.add(createOrbit(1.5, 'y'));
    brainRoot.add(createOrbit(1.45, 'z'));

    // INTERACTION: MOUSE DRAG & ORBIT ROTATION
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let rotationVelocityX = 0;
    let rotationVelocityY = 0.002; // Gentle baseline rotation
    let isUserInteracting = false;

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      isDragging = true;
      isUserInteracting = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onPointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      // Handle drag rotation
      if (isDragging) {
        const deltaX = e.clientX - prevMouseX;
        const deltaY = e.clientY - prevMouseY;
        rotationVelocityY = deltaX * 0.008;
        rotationVelocityX = deltaY * 0.008;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
        return;
      }

      // RAYCASTING FOR HOVER & TOOLTIPS
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), camera);

      // Check electrodes first
      const elecHits = raycaster.intersectObjects(electrodesGroup.children, true);
      if (elecHits.length > 0) {
        let currentObj: THREE.Object3D | null = elecHits[0].object;
        let elecId: string | null = null;
        while (currentObj && !elecId) {
          if (currentObj.userData?.electrodeId) elecId = currentObj.userData.electrodeId;
          currentObj = currentObj.parent;
        }

        if (elecId) {
          const elecData = ELECTRODES_10_20.find((el) => el.id === elecId);
          if (elecData) {
            setHoveredItem({
              type: 'electrode',
              name: `${elecData.name} (${elecData.fullName})`,
              details: `Electrode Impedance: ${elecData.impedanceKohm} kΩ • Signal Quality: ${elecData.signalQuality}%`,
              score: Math.round(elecData.activityScore * 100),
              risk: Math.round(elecData.riskContribution * 100),
              band: elecData.dominantBand,
              screenX: e.clientX - rect.left,
              screenY: e.clientY - rect.top,
            });
            container.style.cursor = 'pointer';
            return;
          }
        }
      }

      // Check regional highlight volumes
      const regionHits = raycaster.intersectObjects(brainRoot.children, false);
      const regionHit = regionHits.find((h) => h.object.userData?.isRegionVolume);
      if (regionHit) {
        const rId = regionHit.object.userData.regionId;
        const regionData = BRAIN_REGIONS.find((r) => r.id === rId);
        if (regionData) {
          setHoveredItem({
            type: 'region',
            name: regionData.name,
            details: regionData.description,
            score: Math.round(regionData.activityScore * 100),
            risk: Math.round(regionData.riskContribution * 100),
            band: regionData.dominantBands.join(', '),
            screenX: e.clientX - rect.left,
            screenY: e.clientY - rect.top,
          });
          container.style.cursor = 'pointer';
          return;
        }
      }

      setHoveredItem(null);
      container.style.cursor = 'grab';
    };

    const onPointerUp = () => {
      isDragging = false;
      setTimeout(() => {
        isUserInteracting = false;
      }, 3000);
    };

    const onClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), camera);

      // Check electrode clicks
      const elecHits = raycaster.intersectObjects(electrodesGroup.children, true);
      if (elecHits.length > 0) {
        let currentObj: THREE.Object3D | null = elecHits[0].object;
        let elecId: string | null = null;
        while (currentObj && !elecId) {
          if (currentObj.userData?.electrodeId) elecId = currentObj.userData.electrodeId;
          currentObj = currentObj.parent;
        }
        if (elecId) {
          onSelectElectrode(elecId);
          // Find associated region
          const elecData = ELECTRODES_10_20.find((el) => el.id === elecId);
          if (elecData) onSelectRegion(elecData.regionId);
          return;
        }
      }

      // Check region clicks
      const regionHits = raycaster.intersectObjects(brainRoot.children, false);
      const regionHit = regionHits.find((h) => h.object.userData?.isRegionVolume);
      if (regionHit) {
        const rId = regionHit.object.userData.regionId;
        onSelectRegion(rId);
        return;
      }
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const zoomFactor = e.deltaY * 0.0025;
      camera.position.z = THREE.MathUtils.clamp(camera.position.z + zoomFactor, 2.2, 7.5);
    };

    container.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    container.addEventListener('click', onClick);
    container.addEventListener('wheel', onWheel, { passive: false });

    // RESIZE OBSERVER
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    // ANIMATION LOOP
    let clock = new THREE.Clock();
    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Damped rotation
      if (brainRoot) {
        if (!isDragging && !isUserInteracting) {
          brainRoot.rotation.y += 0.003;
        } else if (isDragging) {
          brainRoot.rotation.y += rotationVelocityY;
          brainRoot.rotation.x = THREE.MathUtils.clamp(brainRoot.rotation.x + rotationVelocityX, -0.9, 0.9);
          rotationVelocityX *= 0.92;
          rotationVelocityY *= 0.92;
        }
      }

      // Pulse rings on electrodes
      if (electrodesGroup) {
        electrodesGroup.traverse((child) => {
          if (child.userData?.isRing) {
            const isFocal = child.userData.isFocal;
            const pulse = 1 + Math.sin(elapsedTime * (isFocal ? 4 : 2)) * 0.15;
            child.scale.set(pulse, pulse, pulse);
          }
        });
      }

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      resizeObserver.disconnect();
      container.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      container.removeEventListener('click', onClick);
      container.removeEventListener('wheel', onWheel);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update hemisphere visibility & wireframe dynamically
  useEffect(() => {
    if (!brainGroupRef.current) return;
    const leftHemi = brainGroupRef.current.getObjectByName('hemi_left');
    const rightHemi = brainGroupRef.current.getObjectByName('hemi_right');

    if (leftHemi) leftHemi.visible = localHemisphere === 'both' || localHemisphere === 'left';
    if (rightHemi) rightHemi.visible = localHemisphere === 'both' || localHemisphere === 'right';

    // Toggle wireframe visibility
    const wireL = brainGroupRef.current.getObjectByName('wire_left');
    const wireR = brainGroupRef.current.getObjectByName('wire_right');
    if (wireL) wireL.visible = showGyriWireframe;
    if (wireR) wireR.visible = showGyriWireframe;
  }, [localHemisphere, showGyriWireframe]);

  // Update electrode visibility
  useEffect(() => {
    if (electrodesGroupRef.current) {
      electrodesGroupRef.current.visible = showElectrodes;
    }
  }, [showElectrodes]);

  // Highlight selected region or electrode in 3D
  useEffect(() => {
    if (!brainGroupRef.current) return;

    BRAIN_REGIONS.forEach((region) => {
      const vol = brainGroupRef.current?.getObjectByName(`region_vol_${region.id}`) as THREE.Mesh;
      if (vol && vol.material) {
        const isSelected = selectedRegionId === region.id;
        const mat = vol.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = isSelected ? 2.8 : region.activityScore * 1.6;
        mat.opacity = isSelected ? 0.85 : Math.max(0.18, region.activityScore * 0.65);
      }
    });

    if (electrodesGroupRef.current) {
      ELECTRODES_10_20.forEach((elec) => {
        const elecObj = electrodesGroupRef.current?.getObjectByName(`electrode_${elec.id}`);
        if (elecObj) {
          const isSelected = selectedElectrodeId === elec.id;
          const bead = elecObj.children[0] as THREE.Mesh;
          if (bead && bead.material) {
            const mat = bead.material as THREE.MeshStandardMaterial;
            mat.emissiveIntensity = isSelected ? 3.0 : elec.id === 'T3' || elec.id === 'T5' ? 1.6 : 0.8;
            bead.scale.setScalar(isSelected ? 1.6 : 1.0);
          }
        }
      });
    }
  }, [selectedRegionId, selectedElectrodeId]);

  // Preset camera angle views
  const applyViewAngle = (angle: 'default' | 'top' | 'left' | 'right' | 'front') => {
    if (!cameraRef.current || !brainGroupRef.current) return;
    setViewAngle(angle);

    const camera = cameraRef.current;
    const brain = brainGroupRef.current;
    brain.rotation.set(0, 0, 0);

    if (angle === 'default') {
      camera.position.set(0, 1.8, 4.4);
      brain.rotation.y = 0.4;
    } else if (angle === 'top') {
      // Axial view
      camera.position.set(0, 4.8, 0.1);
      camera.lookAt(0, 0, 0);
    } else if (angle === 'left') {
      // Left Sagittal view (inspecting Left Temporal / T3 / T5)
      camera.position.set(-4.5, 0.5, 0.2);
      camera.lookAt(0, 0, 0);
    } else if (angle === 'right') {
      // Right Sagittal view
      camera.position.set(4.5, 0.5, 0.2);
      camera.lookAt(0, 0, 0);
    } else if (angle === 'front') {
      // Coronal Frontal view
      camera.position.set(0, 0.8, 4.5);
      camera.lookAt(0, 0, 0);
    }
  };

  const handleResetCamera = () => {
    applyViewAngle('default');
  };

  const handleZoom = (direction: 'in' | 'out') => {
    if (!cameraRef.current) return;
    const delta = direction === 'in' ? -0.6 : 0.6;
    cameraRef.current.position.z = THREE.MathUtils.clamp(cameraRef.current.position.z + delta, 2.2, 7.5);
  };

  return (
    <div className={`relative w-full h-full min-h-[420px] bg-gradient-to-b from-[#0e1422] to-[#080c14] rounded-xl border border-slate-800/80 overflow-hidden select-none ${className}`}>
      {/* 3D Canvas mount point */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Scientific Overlay Header & Status */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 pointer-events-auto">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-semibold tracking-wider text-slate-200 uppercase">Interactive 3D Cortical Map</span>
          <span className="text-[10px] text-slate-400 font-mono px-1.5 py-0.5 bg-slate-800 rounded">10–20 Standard</span>
        </div>

        {/* View Controls & Hemisphere Inspection Toolbar */}
        <div className="flex items-center gap-1.5 bg-slate-900/85 backdrop-blur-md p-1 rounded-lg border border-slate-700/60 pointer-events-auto">
          <button
            type="button"
            onClick={() => setLocalHemisphere('both')}
            className={`px-2 py-1 text-[11px] font-medium rounded transition-colors ${
              localHemisphere === 'both' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Inspect both hemispheres"
          >
            Both
          </button>
          <button
            type="button"
            onClick={() => setLocalHemisphere('left')}
            className={`px-2 py-1 text-[11px] font-medium rounded transition-colors ${
              localHemisphere === 'left' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Inspect Left Hemisphere (Focal preictal locus)"
          >
            Left (Focal)
          </button>
          <button
            type="button"
            onClick={() => setLocalHemisphere('right')}
            className={`px-2 py-1 text-[11px] font-medium rounded transition-colors ${
              localHemisphere === 'right' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Inspect Right Hemisphere"
          >
            Right
          </button>
        </div>
      </div>

      {/* Floating Scientific View Angles & Camera Utilities */}
      <div className="absolute top-14 right-3 flex flex-col gap-1.5 pointer-events-auto">
        <button
          type="button"
          onClick={() => applyViewAngle('left')}
          className={`px-2 py-1 text-[11px] rounded border font-mono transition-all ${
            viewAngle === 'left'
              ? 'bg-rose-500/25 border-rose-500/50 text-rose-300 font-semibold'
              : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
          title="Left Temporal Lateral View (Primary Preictal Association)"
        >
          Left Lateral (T3/T5)
        </button>
        <button
          type="button"
          onClick={() => applyViewAngle('top')}
          className={`px-2 py-1 text-[11px] rounded border font-mono transition-all ${
            viewAngle === 'top'
              ? 'bg-cyan-500/25 border-cyan-500/50 text-cyan-300 font-semibold'
              : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
          title="Axial Superior View"
        >
          Axial (Top)
        </button>
        <button
          type="button"
          onClick={() => applyViewAngle('front')}
          className={`px-2 py-1 text-[11px] rounded border font-mono transition-all ${
            viewAngle === 'front'
              ? 'bg-cyan-500/25 border-cyan-500/50 text-cyan-300 font-semibold'
              : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
          title="Coronal Frontal View"
        >
          Coronal (Front)
        </button>

        <div className="h-px bg-slate-800 my-0.5" />

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => handleZoom('in')}
            className="p-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded transition-colors"
            title="Zoom in"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => handleZoom('out')}
            className="p-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded transition-colors"
            title="Zoom out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleResetCamera}
            className="p-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded transition-colors"
            title="Reset 3D camera"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          type="button"
          onClick={() => setShowElectrodes(!showElectrodes)}
          className={`p-1.5 text-[10px] rounded border flex items-center justify-center gap-1 transition-colors ${
            showElectrodes ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300' : 'bg-slate-900/80 border-slate-800 text-slate-400'
          }`}
          title="Toggle 10-20 Electrode markers"
        >
          <Layers className="w-3 h-3" />
          <span>Electrodes</span>
        </button>
      </div>

      {/* Bottom Mandatory Scientific Language Label */}
      <div className="absolute bottom-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <div className="bg-slate-950/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] text-slate-300 pointer-events-auto flex items-center gap-2 max-w-xl">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>
            <strong className="text-slate-100 font-medium">Estimated cortical region associated with abnormal EEG activity</strong>. Scalp EEG mapping estimate; not direct surgical source localization.
          </span>
        </div>

        {/* Activity intensity legend */}
        <div className="bg-slate-950/85 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-slate-800 flex items-center gap-3 text-[10px] font-mono pointer-events-auto">
          <span className="text-slate-400">Activity Level:</span>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-slate-500" />
            <span className="text-slate-400">Baseline</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span className="text-cyan-300">Moderate</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-rose-300 font-semibold">Elevated (Preictal)</span>
          </div>
        </div>
      </div>

      {/* Hover Tooltip */}
      {hoveredItem && (
        <div
          className="absolute z-20 pointer-events-none bg-slate-900/95 backdrop-blur-md border border-cyan-500/40 rounded-lg p-2.5 shadow-2xl text-xs max-w-xs transition-opacity duration-150"
          style={{
            left: Math.min(hoveredItem.screenX + 14, (containerRef.current?.clientWidth || 500) - 240),
            top: Math.max(10, hoveredItem.screenY - 10),
          }}
        >
          <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-1.5 mb-1.5">
            <span className="font-semibold text-cyan-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              {hoveredItem.name}
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
              {hoveredItem.type}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] mb-1.5 font-mono">
            <div>
              <span className="text-slate-400 block text-[10px]">Activity Score:</span>
              <span className="text-slate-100 font-bold">{hoveredItem.score}%</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Risk Contribution:</span>
              <span className="text-amber-400 font-bold">{hoveredItem.risk}%</span>
            </div>
          </div>
          {hoveredItem.band && (
            <div className="text-[11px] text-slate-300 mb-1">
              <span className="text-slate-400">Dominant Band: </span>
              <span className="text-cyan-200 font-medium">{hoveredItem.band}</span>
            </div>
          )}
          <p className="text-[10px] text-slate-400 leading-snug line-clamp-2">{hoveredItem.details}</p>
        </div>
      )}
    </div>
  );
};
