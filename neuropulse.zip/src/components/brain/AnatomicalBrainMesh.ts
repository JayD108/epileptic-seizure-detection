import * as THREE from 'three';

export interface LobeMeshDef {
  id: string;
  name: string;
  hemisphere: 'left' | 'right' | 'both';
  baseColor: number;
  atlasColor: number;
  center: THREE.Vector3;
  associatedElectrodes: string[];
}

export const ANATOMICAL_LOBES: LobeMeshDef[] = [
  {
    id: 'left_frontal',
    name: 'Left Frontal Lobe',
    hemisphere: 'left',
    baseColor: 0x0ea5e9, // Sky blue
    atlasColor: 0x38bdf8,
    center: new THREE.Vector3(-0.6, 0.45, 0.7),
    associatedElectrodes: ['Fp1', 'F3', 'Fz'],
  },
  {
    id: 'right_frontal',
    name: 'Right Frontal Lobe',
    hemisphere: 'right',
    baseColor: 0x0ea5e9,
    atlasColor: 0x38bdf8,
    center: new THREE.Vector3(0.6, 0.45, 0.7),
    associatedElectrodes: ['Fp2', 'F4', 'Fz'],
  },
  {
    id: 'left_temporal',
    name: 'Left Temporal Lobe',
    hemisphere: 'left',
    baseColor: 0xf59e0b, // Amber / Preictal focal zone
    atlasColor: 0xf59e0b,
    center: new THREE.Vector3(-1.05, -0.2, 0.15),
    associatedElectrodes: ['T3', 'T5'],
  },
  {
    id: 'right_temporal',
    name: 'Right Temporal Lobe',
    hemisphere: 'right',
    baseColor: 0xf59e0b,
    atlasColor: 0xf59e0b,
    center: new THREE.Vector3(1.05, -0.2, 0.15),
    associatedElectrodes: ['T4', 'T6'],
  },
  {
    id: 'left_parietal',
    name: 'Left Parietal Lobe',
    hemisphere: 'left',
    baseColor: 0xa855f7, // Purple
    atlasColor: 0xa855f7,
    center: new THREE.Vector3(-0.65, 0.65, -0.45),
    associatedElectrodes: ['C3', 'P3', 'Cz', 'Pz'],
  },
  {
    id: 'right_parietal',
    name: 'Right Parietal Lobe',
    hemisphere: 'right',
    baseColor: 0xa855f7,
    atlasColor: 0xa855f7,
    center: new THREE.Vector3(0.65, 0.65, -0.45),
    associatedElectrodes: ['C4', 'P4', 'Cz', 'Pz'],
  },
  {
    id: 'left_occipital',
    name: 'Left Occipital Lobe',
    hemisphere: 'left',
    baseColor: 0x10b981, // Emerald
    atlasColor: 0x10b981,
    center: new THREE.Vector3(-0.5, 0.1, -1.25),
    associatedElectrodes: ['O1'],
  },
  {
    id: 'right_occipital',
    name: 'Right Occipital Lobe',
    hemisphere: 'right',
    baseColor: 0x10b981,
    atlasColor: 0x10b981,
    center: new THREE.Vector3(0.5, 0.1, -1.25),
    associatedElectrodes: ['O2'],
  },
  {
    id: 'cerebellum',
    name: 'Cerebellum',
    hemisphere: 'both',
    baseColor: 0x14b8a6, // Teal
    atlasColor: 0x14b8a6,
    center: new THREE.Vector3(0, -0.65, -1.05),
    associatedElectrodes: [],
  },
  {
    id: 'brainstem',
    name: 'Brainstem',
    hemisphere: 'both',
    baseColor: 0x64748b, // Slate
    atlasColor: 0x64748b,
    center: new THREE.Vector3(0, -0.9, -0.2),
    associatedElectrodes: [],
  },
];

/**
 * Procedurally synthesizes an authentic anatomical cerebral hemisphere.
 * Unlike a simple sphere, this shapes:
 * - Prominent Frontal Pole with rostral orbital surface
 * - Deep Sylvian (lateral) fissure separating the temporal lobe
 * - Temporal Lobe projecting anterior-inferiorly like a curved boxing glove
 * - Parietal arch and Occipital Pole
 * - Longitudinal cerebral fissure (sagittal medial flat cleft)
 * - Fine-grained cortical sulci and gyral folds
 */
export function createAnatomicalHemisphereGeometry(isLeft: boolean): THREE.BufferGeometry {
  const widthSegments = 84;
  const heightSegments = 64;
  const baseGeom = new THREE.SphereGeometry(1.0, widthSegments, heightSegments);
  const pos = baseGeom.attributes.position;
  const v = new THREE.Vector3();

  const sign = isLeft ? -1 : 1;

  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);

    // Normalize base vector
    let nx = v.x;
    let ny = v.y;
    let nz = v.z;

    // 1. Overall Anatomical Proportions:
    // Human brain is elongated anterior-posteriorly (Z), arched superiorly (Y), and laterally convex (X)
    let x = nx * 0.96;
    let y = ny * 0.88;
    let z = nz * 1.22;

    // Shift hemisphere laterally from midline to create authentic Longitudinal Cerebral Fissure
    const medialOffset = 0.08;
    x = x * 0.9 + (sign * medialOffset);

    // Flatten the medial face where the two hemispheres face each other
    if ((isLeft && x > -medialOffset * 1.1) || (!isLeft && x < medialOffset * 1.1)) {
      x = sign * medialOffset;
    }

    // 2. Anatomical Sylvian (Lateral) Fissure & Temporal Lobe protrusion:
    // The temporal lobe lies inferiorly (y < 0) and anterior-mid (z between -0.4 and 0.5)
    // Sylvian fissure creates an anatomical horizontal groove around y = -0.05, z > -0.2
    const inTemporalRegion = (y < 0.1 && z > -0.45 && z < 0.65);
    if (inTemporalRegion) {
      // Bulge out laterally and curve anteriorly (temporal pole)
      const temporalBulge = Math.sin((z + 0.45) / 1.1 * Math.PI) * Math.cos((y + 0.2) * 2.5);
      if (temporalBulge > 0) {
        x += sign * temporalBulge * 0.38;
        y -= temporalBulge * 0.15;
      }
    }

    // Deep Sylvian Fissure indentation above the temporal lobe:
    const sylvianZ = z > -0.3 && z < 0.5;
    const sylvianY = Math.abs(y - 0.02) < 0.16;
    if (sylvianZ && sylvianY && Math.abs(x) > 0.4) {
      const indentation = (1.0 - Math.abs(y - 0.02) / 0.16) * 0.18;
      x -= sign * indentation;
    }

    // 3. Frontal Pole shaping:
    // Slopes downward anteriorly into the orbital surface
    if (z > 0.6) {
      const fT = (z - 0.6) / 0.62;
      y += (1.0 - fT) * 0.08 - fT * 0.12; // curves anterior-inferiorly
      x *= (1.0 - fT * 0.18); // tapers towards frontal pole
    }

    // 4. Occipital Pole:
    // Tapers posteriorly and arches above the cerebellum
    if (z < -0.4) {
      const oT = (-z - 0.4) / 0.82;
      x *= (1.0 - oT * 0.22);
      if (y < -0.1) {
        // Tentorial notch / cerebellar shelf: undercut where cerebellum sits
        y += oT * 0.28;
      }
    }

    // 5. Gyri & Sulci Fold Synthesis (Multiscale anatomical harmonics):
    // Real cortical folds have a characteristic frequency of ~3-6 cm width
    const freq1 = 7.0;
    const freq2 = 14.0;
    const freq3 = 24.0;

    // Sulcal waves oriented predominantly dorso-ventral and antero-posterior
    const gyrus1 = Math.sin(x * freq1 + Math.sin(z * 4.0)) * Math.cos(y * freq1 + z * 2.5);
    const gyrus2 = Math.sin(y * freq2 + x * 5.0) * Math.sin(z * freq2);
    const gyrus3 = Math.sin((x + y + z) * freq3) * 0.5;

    // Combine sulcal modulation, preserving flatter medial longitudinal face
    const isOuterCortex = Math.abs(x) > 0.25;
    const gyralDepth = isOuterCortex ? 0.038 : 0.012;
    const displacement = (gyrus1 * 0.65 + gyrus2 * 0.25 + gyrus3 * 0.1) * gyralDepth;

    // Apply displacement along radial normal
    x += nx * displacement;
    y += ny * displacement;
    z += nz * displacement;

    pos.setXYZ(i, x, y, z);
  }

  baseGeom.computeVertexNormals();
  return baseGeom;
}

/**
 * Synthesizes the Cerebellum with characteristic horizontal folia folds
 */
export function createAnatomicalCerebellumGeometry(): THREE.BufferGeometry {
  const geom = new THREE.SphereGeometry(0.62, 54, 38);
  const pos = geom.attributes.position;
  const v = new THREE.Vector3();

  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    // Flatten dorso-ventrally and widen transversely
    let x = v.x * 1.35;
    let y = v.y * 0.72;
    let z = v.z * 0.88;

    // Midline cerebellar vermis indentation
    const vermisIndent = Math.exp(-Math.pow(x * 3.5, 2)) * 0.08;
    z += vermisIndent;

    // Horizontal folia (tight parallel transverse ridges)
    const folia = Math.sin(y * 42.0) * 0.018;
    x += v.x * folia;
    y += v.y * folia;
    z += v.z * folia;

    // Place underneath occipital lobe
    pos.setXYZ(i, x, y - 0.62, z - 0.95);
  }

  geom.computeVertexNormals();
  return geom;
}

/**
 * Synthesizes Brainstem (Midbrain, Pons bulge, Medulla)
 */
export function createAnatomicalBrainstemGeometry(): THREE.BufferGeometry {
  const geom = new THREE.CylinderGeometry(0.24, 0.18, 1.1, 32, 24);
  const pos = geom.attributes.position;
  const v = new THREE.Vector3();

  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    let x = v.x;
    let y = v.y;
    let z = v.z;

    // Pons prominence (anterior rounded bulge around y = 0.1)
    if (z > 0 && Math.abs(y) < 0.3) {
      const ponsBulge = Math.cos(y * Math.PI / 0.6) * 0.14;
      z += ponsBulge;
      x *= 1.25;
    }

    // Angle slightly backward matching anatomical craniocervical alignment
    z += y * 0.22 - 0.18;
    y -= 0.75;

    pos.setXYZ(i, x, y, z);
  }

  geom.computeVertexNormals();
  return geom;
}

/**
 * Synthesizes Subcortical Structures for "Deep View"
 * (Hippocampus, Amygdala, Thalamus, Corpus Callosum)
 */
export function createSubcorticalStructuresGroup(): THREE.Group {
  const subGroup = new THREE.Group();
  subGroup.name = 'subcortical_deep_structures';

  // 1. Bilateral Hippocampi (C-shaped temporal structure - crucial for epilepsy!)
  const createHippocampus = (isLeft: boolean) => {
    const sign = isLeft ? -1 : 1;
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(sign * 0.45, -0.22, 0.4),  // Head / pes hippocampi near amygdala
      new THREE.Vector3(sign * 0.72, -0.30, 0.1),  // Body curving in temporal horn
      new THREE.Vector3(sign * 0.65, -0.15, -0.3), // Tail arching upwards
      new THREE.Vector3(sign * 0.35, 0.05, -0.55), // Fornix origin
    ]);
    const geom = new THREE.TubeGeometry(curve, 32, 0.07, 12, false);
    const mat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e, // Glowing Coral/Ruby (Epileptogenic focus)
      emissive: 0xf43f5e,
      emissiveIntensity: 0.8,
      roughness: 0.3,
      metalness: 0.2,
    });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.userData = { id: isLeft ? 'left_hippocampus' : 'right_hippocampus', name: `${isLeft ? 'Left' : 'Right'} Hippocampus (Mesial Temporal Focus)` };
    return mesh;
  };

  subGroup.add(createHippocampus(true));
  subGroup.add(createHippocampus(false));

  // 2. Bilateral Thalami (Central sensory relay hubs)
  const createThalamus = (isLeft: boolean) => {
    const sign = isLeft ? -1 : 1;
    const geom = new THREE.SphereGeometry(0.24, 24, 20);
    geom.scale(0.8, 0.7, 1.25);
    const mat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.6,
      roughness: 0.4,
    });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.set(sign * 0.28, 0.08, -0.12);
    mesh.userData = { id: isLeft ? 'left_thalamus' : 'right_thalamus', name: `${isLeft ? 'Left' : 'Right'} Thalamus` };
    return mesh;
  };

  subGroup.add(createThalamus(true));
  subGroup.add(createThalamus(false));

  // 3. Corpus Callosum (C-shaped interhemispheric commissure)
  const ccCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.05, 0.55),  // Genu / Rostrum
    new THREE.Vector3(0, 0.38, 0.15),  // Body
    new THREE.Vector3(0, 0.35, -0.35), // Splenium
  ]);
  const ccGeom = new THREE.TubeGeometry(ccCurve, 28, 0.09, 12, false);
  const ccMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    emissive: 0x94a3b8,
    emissiveIntensity: 0.5,
    roughness: 0.3,
  });
  const ccMesh = new THREE.Mesh(ccGeom, ccMat);
  ccMesh.userData = { id: 'corpus_callosum', name: 'Corpus Callosum (Interhemispheric Tract)' };
  subGroup.add(ccMesh);

  return subGroup;
}
