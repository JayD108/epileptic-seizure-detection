import React, { useState } from 'react';
import { CONNECTIVITY_NODES, CONNECTIVITY_EDGES } from '@/src/lib/mock/eeg';
import { GitCommit, Activity, Radio, Zap } from 'lucide-react';

interface ConnectivityGraphProps {
  selectedChannelId: string | null;
  onSelectChannel: (channelId: string) => void;
  className?: string;
}

export const ConnectivityGraph: React.FC<ConnectivityGraphProps> = ({
  selectedChannelId,
  onSelectChannel,
  className = '',
}) => {
  const [metric, setMetric] = useState<'coherence' | 'correlation' | 'phase_locking'>('coherence');

  const selectedNode = CONNECTIVITY_NODES.find((n) => n.id === selectedChannelId) || CONNECTIVITY_NODES.find((n) => n.id === 'T3')!;

  // Find edges associated with selected channel
  const connectedEdges = CONNECTIVITY_EDGES.filter(
    (e) => e.source === selectedNode.id || e.target === selectedNode.id
  );

  return (
    <div className={`bg-[#0d121d] border border-slate-800 rounded-xl p-4 backdrop-blur-md ${className}`}>
      {/* Header & Metric Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3 mb-3">
        <div>
          <h4 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wide flex items-center gap-1.5">
            <GitCommit className="w-3.5 h-3.5 text-cyan-400" />
            10–20 Channel Connectivity Network
          </h4>
          <span className="text-[10px] text-slate-400 font-mono">
            Inter-electrode synchrony & corticocortical functional coupling
          </span>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded p-0.5 text-xs font-mono">
          {(['coherence', 'correlation', 'phase_locking'] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMetric(m)}
              className={`px-2 py-0.5 rounded text-[10px] capitalize transition-colors ${
                metric === m ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {m.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* 2D Cranial Schematic with Nodes and SVG Edges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
        {/* SVG Network Map */}
        <div className="md:col-span-2 relative w-full h-[260px] bg-[#080c14] border border-slate-800/80 rounded-lg overflow-hidden flex items-center justify-center">
          <svg className="w-full h-full" viewBox="0 0 100 100">
            {/* Cranial Head Oval Outline */}
            <ellipse
              cx="50"
              cy="50"
              rx="44"
              ry="46"
              fill="none"
              stroke="#1e293b"
              strokeWidth="1.2"
              strokeDasharray="2 2"
            />
            {/* Nose indicator at top */}
            <path d="M 47 4 L 50 1 L 53 4" fill="none" stroke="#334155" strokeWidth="1.2" />
            {/* Left/Right Ear indicators */}
            <path d="M 5 45 C 3 47, 3 53, 5 55" fill="none" stroke="#334155" strokeWidth="1.2" />
            <path d="M 95 45 C 97 47, 97 53, 95 55" fill="none" stroke="#334155" strokeWidth="1.2" />

            {/* Render Edges */}
            {CONNECTIVITY_EDGES.map((edge, idx) => {
              const srcNode = CONNECTIVITY_NODES.find((n) => n.id === edge.source);
              const tgtNode = CONNECTIVITY_NODES.find((n) => n.id === edge.target);
              if (!srcNode || !tgtNode) return null;

              const isAssociatedWithSelected = edge.source === selectedChannelId || edge.target === selectedChannelId;
              const isHighCoupling = edge.weight >= 0.75;

              return (
                <line
                  key={`${edge.source}-${edge.target}-${idx}`}
                  x1={srcNode.x}
                  y1={srcNode.y}
                  x2={tgtNode.x}
                  y2={tgtNode.y}
                  stroke={
                    isAssociatedWithSelected
                      ? '#38bdf8'
                      : isHighCoupling
                      ? '#f43f5e'
                      : '#334155'
                  }
                  strokeWidth={
                    isAssociatedWithSelected ? Math.max(edge.weight * 3.0, 1.5) : edge.weight * 1.8
                  }
                  strokeOpacity={isAssociatedWithSelected ? 0.95 : edge.weight * 0.7}
                />
              );
            })}

            {/* Render Nodes */}
            {CONNECTIVITY_NODES.map((node) => {
              const isSelected = selectedChannelId === node.id;
              const isFocal = node.id === 'T3' || node.id === 'T5';

              return (
                <g
                  key={node.id}
                  onClick={() => onSelectChannel(node.id)}
                  className="cursor-pointer transition-transform hover:scale-125"
                  style={{ transformOrigin: `${node.x}% ${node.y}%` }}
                >
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={isSelected ? 4.5 : 3.2}
                    fill={isSelected ? '#38bdf8' : isFocal ? '#f43f5e' : '#1e293b'}
                    stroke={isSelected ? '#ffffff' : isFocal ? '#f43f5e' : '#475569'}
                    strokeWidth="0.8"
                  />
                  <text
                    x={node.x}
                    y={node.y + 1.2}
                    fontSize="2.4"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                    fill={isSelected ? '#090d15' : '#e2e8f0'}
                  >
                    {node.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Node Telemetry & Edge Details */}
        <div className="space-y-3 font-mono text-xs">
          <div className="p-3 bg-slate-900/70 border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
              <span className="text-slate-400">Selected Node:</span>
              <span className="font-bold text-cyan-300 text-sm">{selectedNode.label}</span>
            </div>
            <div className="text-[11px] text-slate-300 space-y-1">
              <div>Cortical Region: <strong>{selectedNode.region}</strong></div>
              <div>Connected Degree: <strong>{connectedEdges.length} Derivations</strong></div>
              <div>Metric: <strong className="capitalize">{metric.replace('_', ' ')}</strong></div>
            </div>
          </div>

          <div className="p-2.5 bg-slate-900/40 border border-slate-800 rounded-lg max-h-36 overflow-y-auto scrollbar-thin">
            <span className="text-[10px] text-slate-400 block mb-1 uppercase font-bold">
              Pairwise Edge Values:
            </span>
            <div className="space-y-1">
              {connectedEdges.map((e) => {
                const partner = e.source === selectedNode.id ? e.target : e.source;
                return (
                  <div key={`${e.source}-${e.target}`} className="flex justify-between items-center text-[11px]">
                    <span className="text-slate-300">{selectedNode.label} ↔ {partner}</span>
                    <span className={`font-bold ${e.weight > 0.75 ? 'text-rose-400' : 'text-cyan-300'}`}>
                      {e.weight.toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
