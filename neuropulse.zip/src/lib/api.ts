import {
  BrainRegionActivity,
  EEGWindow,
  ModelMetrics,
  Patient,
  PatientHistoryEvent,
  Prediction,
  SystemReport,
} from '@/src/types';
import { BRAIN_REGIONS } from './mock/brain';
import { generateSpectrogramData, generateSyntheticEEG } from './mock/eeg';
import { MOCK_HISTORY_EVENTS, MOCK_MODELS } from './mock/models';
import { MOCK_PATIENTS } from './mock/patients';
import { PRIMARY_PREDICTION } from './mock/predictions';

const FASTAPI_BASE_URL = (typeof process !== 'undefined' && process.env?.FASTAPI_BACKEND_URL) || '';

/**
 * Upload an EDF / BDF / CSV EEG file to the prediction backend
 */
export async function uploadEEG(file: File, patientId: string): Promise<{ success: boolean; recordingId: string; message: string }> {
  if (FASTAPI_BASE_URL) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('patient_id', patientId);
    const res = await fetch(`${FASTAPI_BASE_URL}/api/eeg/upload`, {
      method: 'POST',
      body: formData,
    });
    if (!res.ok) throw new Error(`Upload failed: ${res.statusText}`);
    return res.json();
  }

  // Frontend mock response simulation
  await new Promise((resolve) => setTimeout(resolve, 800));
  return {
    success: true,
    recordingId: `rec-${Date.now().toString(36)}`,
    message: `File ${file.name} successfully parsed (17 channels, 256 Hz 10-20 montage).`,
  };
}

/**
 * Fetch EEG data window
 */
export async function getEEG(
  patientId: string,
  recordingId: string,
  options?: { timeOffset?: number; durationSec?: number; severity?: number }
): Promise<EEGWindow> {
  const timeOffset = options?.timeOffset ?? 0;
  const durationSec = options?.durationSec ?? 4;
  const severity = options?.severity ?? 0.73;

  if (FASTAPI_BASE_URL) {
    const query = new URLSearchParams({
      patient_id: patientId,
      recording_id: recordingId,
      offset: timeOffset.toString(),
      duration: durationSec.toString(),
    });
    const res = await fetch(`${FASTAPI_BASE_URL}/api/eeg/window?${query}`);
    if (res.ok) return res.json();
  }

  const channels = generateSyntheticEEG(240, timeOffset, severity);
  const timePoints = Array.from({ length: 240 }, (_, i) => i / 60);

  return {
    startTimeSec: timeOffset / 60,
    durationSec,
    samplingRateHz: 60,
    channels,
    timePoints,
  };
}

/**
 * Fetch model prediction and explainability
 */
export async function getPrediction(
  patientId: string,
  recordingId: string,
  severityOverride?: number
): Promise<Prediction> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/prediction/latest?patient_id=${patientId}&recording_id=${recordingId}`);
    if (res.ok) return res.json();
  }

  if (severityOverride !== undefined) {
    const risk = Math.round(severityOverride * 100);
    const riskLevel = risk < 35 ? 'Low' : risk < 65 ? 'Moderate' : 'Elevated';
    return {
      ...PRIMARY_PREDICTION,
      riskScore: risk,
      riskLevel,
    };
  }

  return PRIMARY_PREDICTION;
}

export const fetchPrediction = getPrediction;

/**
 * Fetch cortical regional activity estimates
 */
export async function getBrainActivity(patientId: string, recordingId: string): Promise<BrainRegionActivity[]> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/brain/activity?patient_id=${patientId}&recording_id=${recordingId}`);
    if (res.ok) return res.json();
  }

  return BRAIN_REGIONS;
}

/**
 * Fetch patient profiles and recording listings
 */
export async function getPatient(patientId: string): Promise<Patient | undefined> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/patients/${patientId}`);
    if (res.ok) return res.json();
  }

  return MOCK_PATIENTS.find((p) => p.id === patientId) || MOCK_PATIENTS[0];
}

/**
 * Fetch list of all patients
 */
export async function getPatients(): Promise<Patient[]> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/patients`);
    if (res.ok) return res.json();
  }
  return MOCK_PATIENTS;
}

/**
 * Fetch model benchmarks and registry comparison
 */
export async function getModelMetrics(): Promise<ModelMetrics[]> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/models/metrics`);
    if (res.ok) return res.json();
  }
  return MOCK_MODELS;
}

/**
 * Fetch historical prediction events
 */
export async function getPatientHistory(patientId: string): Promise<PatientHistoryEvent[]> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/history?patient_id=${patientId}`);
    if (res.ok) return res.json();
  }
  return MOCK_HISTORY_EVENTS.filter((e) => e.patientId === patientId || !patientId);
}

/**
 * Generate academic research report preview
 */
export async function generateReport(patientId: string, recordingId: string): Promise<SystemReport> {
  if (FASTAPI_BASE_URL) {
    const res = await fetch(`${FASTAPI_BASE_URL}/api/reports/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ patient_id: patientId, recording_id: recordingId }),
    });
    if (res.ok) return res.json();
  }

  const patient = MOCK_PATIENTS.find((p) => p.id === patientId) || MOCK_PATIENTS[0];
  const rec = patient.recordings.find((r) => r.id === recordingId) || patient.recordings[0];

  return {
    id: `REP-${Date.now().toString(36).toUpperCase()}`,
    patientId: patient.code,
    recordingId: rec.code,
    generatedAt: new Date().toISOString(),
    institution: 'Neurological Data Science & Neuro-Engineering Laboratory',
    primaryInvestigator: 'Academic ML Evaluation Protocol (PI: Dr. C. Mercer, MD/PhD)',
    signalQuality: rec.qualityScore,
    recordingDuration: rec.duration,
    predictionSummary: {
      peakRisk: 73,
      riskCategory: 'Elevated',
      predictionHorizon: '10–30 min',
      estimatedRegion: 'Left Temporal Region',
      associatedChannels: ['T3', 'T5', 'C3'],
    },
    dominantFeatures: [
      { feature: 'Theta Power (4-8 Hz)', contribution: '+24%', baselineShift: '+31% over interictal norm' },
      { feature: 'Spectral Entropy (Wiener)', contribution: '+18%', baselineShift: '-26% disorder collapse' },
      { feature: 'Channel Synchrony (PLV)', contribution: '+14%', baselineShift: '+41% ipsilateral coupling' },
      { feature: 'Hjorth Mobility', contribution: '+11%', baselineShift: '-52% frequency dispersion' },
      { feature: 'Line Length Arc', contribution: '+8%', baselineShift: '+29% path complexity' },
    ],
    limitationsDisclaimer:
      'NeuroPulse is an experimental machine learning research prototype developed strictly for academic investigation and algorithmic explainability. It is not an FDA/CE cleared medical software device and must not be utilized for clinical diagnostic or acute treatment decision making.',
  };
}
