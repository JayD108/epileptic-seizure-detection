import { ConnectivityEdge, ConnectivityNode, EEGChannel, FrequencyBand } from '@/src/types';

// Physiological frequency band specs
export const FREQUENCY_BANDS: FrequencyBand[] = [
  {
    name: 'Delta',
    range: '0.5–4.0 Hz',
    absolutePower: 18.4,
    relativePower: 16.2,
    baselineDeltaPercent: -4,
    description: 'Slow polymorphic background oscillations; elevated during deep sleep and pathological encephalopathy.',
  },
  {
    name: 'Theta',
    range: '4.0–8.0 Hz',
    absolutePower: 44.8,
    relativePower: 39.4,
    baselineDeltaPercent: +31,
    description: 'Rhythmic 5.2 Hz slowing associated with preictal focal activation and synchronizing neural assemblies.',
  },
  {
    name: 'Alpha',
    range: '8.0–13.0 Hz',
    absolutePower: 27.2,
    relativePower: 23.9,
    baselineDeltaPercent: +8,
    description: 'Posterior dominant rhythm (PDR), responsive to eye closure; moderate desynchronization during preictal drift.',
  },
  {
    name: 'Beta',
    range: '13.0–30.0 Hz',
    absolutePower: 15.6,
    relativePower: 13.7,
    baselineDeltaPercent: -2,
    description: 'Fast cortical background activity; local frontocentral sensorimotor rhythm.',
  },
  {
    name: 'Gamma',
    range: '30.0–45.0 Hz',
    absolutePower: 7.8,
    relativePower: 6.8,
    baselineDeltaPercent: +1,
    description: 'High-frequency cortical processing; transient phase-amplitude coupling with theta envelopes.',
  },
];

export const CHANNEL_METADATA: { id: string; label: string; region: string; defaultDominant: string; isTemporalOrFocal: boolean }[] = [
  { id: 'Fp1', label: 'Fp1', region: 'Left Frontopolar', defaultDominant: 'Beta', isTemporalOrFocal: false },
  { id: 'Fp2', label: 'Fp2', region: 'Right Frontopolar', defaultDominant: 'Beta', isTemporalOrFocal: false },
  { id: 'F3', label: 'F3', region: 'Left Mid-Frontal', defaultDominant: 'Theta', isTemporalOrFocal: true },
  { id: 'F4', label: 'F4', region: 'Right Mid-Frontal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'Fz', label: 'Fz', region: 'Midline Frontal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'C3', label: 'C3', region: 'Left Central', defaultDominant: 'Theta', isTemporalOrFocal: true },
  { id: 'Cz', label: 'Cz', region: 'Midline Vertex', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'C4', label: 'C4', region: 'Right Central', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'T3', label: 'T3', region: 'Left Mid-Temporal', defaultDominant: 'Theta', isTemporalOrFocal: true },
  { id: 'T4', label: 'T4', region: 'Right Mid-Temporal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'T5', label: 'T5', region: 'Left Posterior-Temporal', defaultDominant: 'Theta', isTemporalOrFocal: true },
  { id: 'T6', label: 'T6', region: 'Right Posterior-Temporal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'P3', label: 'P3', region: 'Left Parietal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'Pz', label: 'Pz', region: 'Midline Parietal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'P4', label: 'P4', region: 'Right Parietal', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'O1', label: 'O1', region: 'Left Occipital', defaultDominant: 'Alpha', isTemporalOrFocal: false },
  { id: 'O2', label: 'O2', region: 'Right Occipital', defaultDominant: 'Alpha', isTemporalOrFocal: false },
];

/**
 * Generates realistic synthetic multi-channel EEG signals
 * with physiologically plausible waveforms (Alpha, Theta slowing, Sharp Wave transients in T3/T5).
 */
export function generateSyntheticEEG(
  pointCount: number = 240,
  timeOffset: number = 0,
  preictalSeverity: number = 0.73 // 0 to 1
): EEGChannel[] {
  const sampleRate = 60; // 60 data points per second for smooth 60fps rendering

  return CHANNEL_METADATA.map((meta, chIndex) => {
    const samples: number[] = [];
    const isFocal = meta.isTemporalOrFocal;
    const isT3T5 = meta.id === 'T3' || meta.id === 'T5';

    // Channel-specific phase seed
    const phaseSeed = chIndex * 1.37;

    for (let i = 0; i < pointCount; i++) {
      const t = (i + timeOffset) / sampleRate;

      // 1. Slow drift (0.3 Hz baseline wandering)
      const slowDrift = Math.sin(2 * Math.PI * 0.3 * t + phaseSeed) * 6;

      // 2. Alpha rhythm (10.2 Hz) - modulated envelope
      const alphaAmp = (meta.id.startsWith('O') || meta.id.startsWith('P')) ? 22 : 12;
      const alphaEnvelope = 0.7 + 0.3 * Math.sin(2 * Math.PI * 0.8 * t + phaseSeed);
      const alpha = Math.sin(2 * Math.PI * 10.2 * t + phaseSeed * 0.5) * alphaAmp * alphaEnvelope;

      // 3. Beta rhythm (18.5 Hz)
      const beta = Math.sin(2 * Math.PI * 18.5 * t + phaseSeed * 2.1) * 4.5;

      // 4. Preictal Theta slowing (5.2 Hz) - strongly amplified in focal T3, T5, C3
      let theta = 0;
      if (isFocal) {
        const thetaBoost = isT3T5 ? (18 + preictalSeverity * 45) : (8 + preictalSeverity * 20);
        // Periodic bursting
        const burstMod = 0.6 + 0.4 * Math.sin(2 * Math.PI * 0.45 * t + phaseSeed);
        theta = Math.sin(2 * Math.PI * 5.2 * t + phaseSeed * 0.2) * thetaBoost * burstMod;

        // Add subtle harmonic spike/sharp component if high preictal
        if (preictalSeverity > 0.5 && isT3T5) {
          const spikeCycle = (t * 2.6) % 1.0;
          if (spikeCycle > 0.88) {
            theta += Math.sin((spikeCycle - 0.88) * Math.PI / 0.12) * 28 * preictalSeverity;
          }
        }
      } else {
        theta = Math.sin(2 * Math.PI * 5.5 * t + phaseSeed) * 5;
      }

      // 5. Physiological low-amplitude noise (pink noise approx)
      const noise = (Math.sin(t * 71.3 + phaseSeed) * 1.5) + (Math.cos(t * 113.7 + phaseSeed) * 1.2);

      const totalAmplitude = slowDrift + alpha + beta + theta + noise;
      samples.push(Number(totalAmplitude.toFixed(2)));
    }

    // Calculate RMS amplitude
    const sumSq = samples.reduce((acc, v) => acc + v * v, 0);
    const rms = Number(Math.sqrt(sumSq / samples.length).toFixed(1));

    let status: 'normal' | 'elevated' | 'critical' = 'normal';
    if (isT3T5 && preictalSeverity > 0.65) status = 'critical';
    else if (isFocal && preictalSeverity > 0.4) status = 'elevated';

    return {
      id: meta.id,
      label: meta.label,
      region: meta.region,
      dominantBand: isT3T5 && preictalSeverity > 0.4 ? 'Theta' : meta.defaultDominant,
      rmsAmplitude: rms,
      status,
      samples,
    };
  });
}

/**
 * 2D Spectrogram data matrix generator
 */
export interface SpectrogramSlice {
  timeLabel: string;
  timeSec: number;
  frequencies: { hz: number; power: number }[];
}

export function generateSpectrogramData(
  channelId: string = 'T3',
  sliceCount: number = 24,
  preictalSeverity: number = 0.73
): SpectrogramSlice[] {
  const isTemporal = channelId === 'T3' || channelId === 'T5';
  const slices: SpectrogramSlice[] = [];

  // Frequencies from 1 to 40 Hz (step by 2 Hz)
  const freqBins = [1, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40];

  for (let s = 0; s < sliceCount; s++) {
    const timeSec = s * 1.25;
    const timeLabel = `${timeSec.toFixed(1)}s`;

    const frequencies = freqBins.map((hz) => {
      let basePower = Math.exp(-hz / 14) * 20;

      // Alpha peak around 10 Hz
      if (hz >= 8 && hz <= 12) {
        basePower += 22 * Math.exp(-Math.pow(hz - 10, 2) / 4);
      }

      // Theta peak around 5.2 Hz (heavily elevated in T3/T5 during preictal)
      if (hz >= 4 && hz <= 7 && isTemporal) {
        const timeBurst = 1 + 0.5 * Math.sin(s * 0.4);
        basePower += (15 + preictalSeverity * 55) * timeBurst * Math.exp(-Math.pow(hz - 5.2, 2) / 3);
      }

      // Add mild organic fluctuation
      const organic = 1 + 0.15 * Math.sin(s * 1.1 + hz * 0.3);
      const power = Math.max(2, basePower * organic);

      return {
        hz,
        power: Number(power.toFixed(1)),
      };
    });

    slices.push({ timeLabel, timeSec, frequencies });
  }

  return slices;
}

// 10-20 Connectivity map coordinates (2D cranial projection)
export const CONNECTIVITY_NODES: ConnectivityNode[] = [
  { id: 'Fp1', label: 'Fp1', x: 38, y: 15, region: 'Left Frontal' },
  { id: 'Fp2', label: 'Fp2', x: 62, y: 15, region: 'Right Frontal' },
  { id: 'F3', label: 'F3', x: 32, y: 32, region: 'Left Frontal' },
  { id: 'Fz', label: 'Fz', x: 50, y: 28, region: 'Midline Frontal' },
  { id: 'F4', label: 'F4', x: 68, y: 32, region: 'Right Frontal' },
  { id: 'T3', label: 'T3', x: 12, y: 50, region: 'Left Temporal' },
  { id: 'C3', label: 'C3', x: 32, y: 50, region: 'Left Central' },
  { id: 'Cz', label: 'Cz', x: 50, y: 50, region: 'Midline Vertex' },
  { id: 'C4', label: 'C4', x: 68, y: 50, region: 'Right Central' },
  { id: 'T4', label: 'T4', x: 88, y: 50, region: 'Right Temporal' },
  { id: 'T5', label: 'T5', x: 20, y: 68, region: 'Left Temporal' },
  { id: 'P3', label: 'P3', x: 34, y: 68, region: 'Left Parietal' },
  { id: 'Pz', label: 'Pz', x: 50, y: 68, region: 'Midline Parietal' },
  { id: 'P4', label: 'P4', x: 66, y: 68, region: 'Right Parietal' },
  { id: 'T6', label: 'T6', x: 80, y: 68, region: 'Right Temporal' },
  { id: 'O1', label: 'O1', x: 38, y: 86, region: 'Left Occipital' },
  { id: 'O2', label: 'O2', x: 62, y: 86, region: 'Right Occipital' },
];

export const CONNECTIVITY_EDGES: ConnectivityEdge[] = [
  // High preictal connectivity in Left Temporal network
  { source: 'T3', target: 'T5', weight: 0.89, metric: 'coherence' },
  { source: 'T3', target: 'C3', weight: 0.81, metric: 'coherence' },
  { source: 'T3', target: 'F3', weight: 0.74, metric: 'coherence' },
  { source: 'T5', target: 'P3', weight: 0.68, metric: 'coherence' },
  { source: 'F3', target: 'C3', weight: 0.65, metric: 'coherence' },

  // Physiological anterior & posterior connections
  { source: 'Fp1', target: 'F3', weight: 0.45, metric: 'coherence' },
  { source: 'Fp2', target: 'F4', weight: 0.42, metric: 'coherence' },
  { source: 'Fp1', target: 'Fp2', weight: 0.52, metric: 'coherence' },
  { source: 'F3', target: 'Fz', weight: 0.48, metric: 'coherence' },
  { source: 'F4', target: 'Fz', weight: 0.44, metric: 'coherence' },
  { source: 'C3', target: 'Cz', weight: 0.38, metric: 'coherence' },
  { source: 'C4', target: 'Cz', weight: 0.36, metric: 'coherence' },
  { source: 'T4', target: 'C4', weight: 0.34, metric: 'coherence' },
  { source: 'T4', target: 'T6', weight: 0.39, metric: 'coherence' },
  { source: 'P3', target: 'Pz', weight: 0.51, metric: 'coherence' },
  { source: 'P4', target: 'Pz', weight: 0.49, metric: 'coherence' },
  { source: 'P3', target: 'O1', weight: 0.62, metric: 'coherence' },
  { source: 'P4', target: 'O2', weight: 0.60, metric: 'coherence' },
  { source: 'O1', target: 'O2', weight: 0.71, metric: 'coherence' },
];
