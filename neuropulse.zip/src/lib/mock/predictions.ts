import { FeatureContribution, Prediction, PredictionTimelineEvent } from '@/src/types';

export const MOCK_FEATURES: FeatureContribution[] = [
  {
    id: 'feat-theta-power',
    feature: 'Theta Band Relative Power (4–8 Hz)',
    category: 'spectral',
    impact: 0.34,
    percentage: 24,
    direction: 'increase',
    value: '0.41 (norm: 0.17)',
    description: 'Marked increase in 5.2 Hz rhythmic sinusoidal oscillations over temporal leads T3 & T5.',
  },
  {
    id: 'feat-spectral-entropy',
    feature: 'Spectral Entropy (Wiener / Shannon)',
    category: 'complexity',
    impact: 0.26,
    percentage: 18,
    direction: 'increase',
    value: '0.62 (norm: 0.88)',
    description: 'Steep drop in spectral disorder reflecting progressive frequency crystallization and synchrony.',
  },
  {
    id: 'feat-channel-sync',
    feature: 'Channel Connectivity (PLV & Coherence)',
    category: 'connectivity',
    impact: 0.20,
    percentage: 14,
    direction: 'increase',
    value: '0.79 (norm: 0.38)',
    description: 'Elevated Phase Locking Value between ipsilateral temporal (T3-T5) and frontocentral networks.',
  },
  {
    id: 'feat-hjorth-mobility',
    feature: 'Hjorth Mobility (Mean Frequency Parameter)',
    category: 'temporal',
    impact: 0.16,
    percentage: 11,
    direction: 'increase',
    value: '3.4 rad/s (norm: 7.1)',
    description: 'Drastic negative shift in signal differential ratio indicating persistent low-frequency domination.',
  },
  {
    id: 'feat-line-length',
    feature: 'Normalized Line Length & Curve Arc',
    category: 'complexity',
    impact: 0.11,
    percentage: 8,
    direction: 'increase',
    value: '1.42 (norm: 0.95)',
    description: 'Cumulative point-to-point Euclidean path elevation produced by sharp epileptiform transients.',
  },
  {
    id: 'feat-pac',
    feature: 'Phase-Amplitude Coupling (Theta-Gamma PAC)',
    category: 'spectral',
    impact: 0.08,
    percentage: 5,
    direction: 'increase',
    value: 'Modulation Index: 0.12',
    description: 'Cross-frequency modulation where 5 Hz phase modulates low-gamma (32-40 Hz) amplitude envelopes.',
  },
];

export const MOCK_TIMELINE_EVENTS: PredictionTimelineEvent[] = [
  {
    timeSec: -1800, // 30 min ago
    timeLabel: '-30m',
    riskScore: 18,
    phase: 'INTERICTAL',
    note: 'Baseline resting state. Dominant 10.2 Hz posterior alpha.',
  },
  {
    timeSec: -1200, // 20 min ago
    timeLabel: '-20m',
    riskScore: 24,
    phase: 'INTERICTAL',
    note: 'Sporadic physiological desynchronization.',
  },
  {
    timeSec: -600, // 10 min ago
    timeLabel: '-10m',
    riskScore: 46,
    phase: 'PREICTAL',
    note: 'Preictal state drift: intermittent rhythmic left temporal theta bursts begin.',
  },
  {
    timeSec: -180, // 3 min ago
    timeLabel: '-3m',
    riskScore: 68,
    phase: 'PREICTAL',
    note: 'Coherence surge between T3 and T5. Spectral entropy drop.',
  },
  {
    timeSec: 0, // CURRENT NOW
    timeLabel: 'NOW',
    riskScore: 73,
    phase: 'MODEL_ALERT',
    note: 'MODEL ALERT: Persistent preictal pattern detected exceeding threshold (0.65).',
  },
  {
    timeSec: 600, // +10 min
    timeLabel: '+10m',
    riskScore: 78,
    phase: 'SEIZURE_WINDOW',
    note: 'Onset of Estimated Prediction Horizon (10–30 min window).',
  },
  {
    timeSec: 1200, // +20 min
    timeLabel: '+20m',
    riskScore: 82,
    phase: 'SEIZURE_WINDOW',
    note: 'Peak statistical susceptibility window.',
  },
  {
    timeSec: 1800, // +30 min
    timeLabel: '+30m',
    riskScore: 65,
    phase: 'SEIZURE_WINDOW',
    note: 'Upper boundary of current prediction horizon.',
  },
];

export const PRIMARY_PREDICTION: Prediction = {
  timestamp: '2026-09-09T18:00:00Z',
  riskScore: 73,
  riskLevel: 'Elevated',
  predictionHorizon: '10–30 min',
  horizonMinutesMin: 10,
  horizonMinutesMax: 30,
  estimatedRegion: 'Left Temporal Region',
  associatedChannels: ['T3', 'T5', 'C3'],
  modelName: 'XGBoost + Morlet Wavelet Ensemble',
  modelVersion: 'v1.4-rc2 (Cross-Patient Validated)',
  confidenceInterval: [67, 79],
  signalQualityScore: 94,
  topFeatures: MOCK_FEATURES,
  timeline: MOCK_TIMELINE_EVENTS,
  currentTimeOffsetSec: 0,
};

// Simulation presets for demo transitions
export const DEMO_PRESETS: Record<string, {
  label: string;
  brainState: string;
  riskScore: number;
  riskLevel: 'Low' | 'Moderate' | 'Elevated';
  horizon: string;
  region: string;
  topChannels: string[];
  features: FeatureContribution[];
}> = {
  interictal: {
    label: '1. Baseline Interictal',
    brainState: 'Resting Baseline Physiological State',
    riskScore: 19,
    riskLevel: 'Low',
    horizon: '> 60 min',
    region: 'No Focal Anomaly',
    topChannels: ['O1', 'O2', 'Cz'],
    features: [
      { id: 'f1', feature: 'Posterior Alpha Power', category: 'spectral', impact: -0.22, percentage: -18, direction: 'decrease', value: '0.52', description: 'Strong stable 10.2 Hz alpha background.' },
      { id: 'f2', feature: 'Global Spectral Entropy', category: 'complexity', impact: -0.19, percentage: -15, direction: 'decrease', value: '0.91', description: 'High broadband physiological entropy.' },
      { id: 'f3', feature: 'Inter-channel Desynchrony', category: 'connectivity', impact: -0.14, percentage: -11, direction: 'decrease', value: '0.22', description: 'Normal distributed corticocortical network activity.' },
    ],
  },
  early_preictal: {
    label: '2. Early Preictal Drift',
    brainState: 'Emerging Focal Sub-Band Alterations',
    riskScore: 49,
    riskLevel: 'Moderate',
    horizon: '25–45 min',
    region: 'Left Temporal Region (Mild)',
    topChannels: ['T3', 'F3'],
    features: [
      { id: 'f1', feature: 'Theta Band Relative Power', category: 'spectral', impact: 0.18, percentage: 14, direction: 'increase', value: '0.29', description: 'Mild 5-6 Hz drift in left temporal.' },
      { id: 'f2', feature: 'Phase Synchronization', category: 'connectivity', impact: 0.15, percentage: 11, direction: 'increase', value: '0.51', description: 'Nascent ipsilateral phase locking.' },
      { id: 'f3', feature: 'Line Length Delta', category: 'complexity', impact: 0.12, percentage: 9, direction: 'increase', value: '1.14', description: 'Subtle amplitude gradient sharpening.' },
    ],
  },
  elevated_preictal: {
    label: '3. Elevated Preictal (Current Demo Target)',
    brainState: 'Elevated Pre-Seizure Activity',
    riskScore: 73,
    riskLevel: 'Elevated',
    horizon: '10–30 min',
    region: 'Left Temporal Region',
    topChannels: ['T3', 'T5', 'C3'],
    features: MOCK_FEATURES,
  },
  critical_preictal: {
    label: '4. Impending Preictal Burst',
    brainState: 'High-Probability Preictal Convergence',
    riskScore: 89,
    riskLevel: 'Elevated',
    horizon: '5–15 min',
    region: 'Left Frontotemporal Complex',
    topChannels: ['T3', 'T5', 'F3', 'C3'],
    features: [
      { id: 'f1', feature: 'Theta Band Relative Power (4–8 Hz)', category: 'spectral', impact: 0.44, percentage: 32, direction: 'increase', value: '0.58', description: 'High-amplitude rhythmic temporal runs.' },
      { id: 'f2', feature: 'Spectral Entropy Drop', category: 'complexity', impact: 0.35, percentage: 25, direction: 'increase', value: '0.48', description: 'Extreme stereotypic synchronization.' },
      { id: 'f3', feature: 'Channel PLV (T3-T5-C3)', category: 'connectivity', impact: 0.28, percentage: 20, direction: 'increase', value: '0.88', description: 'Dense network phase entanglement.' },
    ],
  },
};

export const FEATURE_CONTRIBUTIONS = MOCK_FEATURES;

