import React, { useState, useEffect } from 'react';
import { AppMode, Patient, Prediction, FeatureContribution, PatientHistoryEvent } from '@/src/types';
import { MOCK_PATIENTS } from '@/src/lib/mock/patients';
import { BRAIN_REGIONS, ELECTRODES_10_20 } from '@/src/lib/mock/brain';
import { FEATURE_CONTRIBUTIONS } from '@/src/lib/mock/predictions';
import { fetchPrediction } from '@/src/lib/api';

// Layout
import { TopBar } from '@/src/components/layout/TopBar';
import { Sidebar, NavigationPage } from '@/src/components/layout/Sidebar';

// 3D Brain Components
import { BrainCanvas } from '@/src/components/brain/BrainCanvas';
import { BrainActivityStudio } from '@/src/components/brain/BrainActivityStudio';
import { ElectrodeInspector } from '@/src/components/brain/ElectrodeInspector';
import { RegionalActivityList } from '@/src/components/brain/RegionalActivityList';

// EEG & Spectral Components
import { EEGViewer } from '@/src/components/eeg/EEGViewer';
import { SpectrogramViewer } from '@/src/components/eeg/SpectrogramViewer';
import { FrequencyBandPanel } from '@/src/components/eeg/FrequencyBandPanel';

// Prediction & Explainability Components
import { TopOverviewCards } from '@/src/components/prediction/TopOverviewCards';
import { RiskGauge } from '@/src/components/prediction/RiskGauge';
import { PredictionTimeline } from '@/src/components/prediction/PredictionTimeline';
import { WhyPredictionPanel } from '@/src/components/prediction/WhyPredictionPanel';
import { ConnectivityGraph } from '@/src/components/connectivity/ConnectivityGraph';

// Dedicated Views
import { PatientModeView } from '@/src/components/views/PatientModeView';
import { ModelLabView } from '@/src/components/views/ModelLabView';
import { PatientHistoryView } from '@/src/components/views/PatientHistoryView';
import { ReportsView } from '@/src/components/views/ReportsView';
import { DocsView } from '@/src/components/views/DocsView';

// Icons
import { ShieldAlert, AlertTriangle, Sparkles, SlidersHorizontal, Layers, CheckCircle2, ChevronRight, Maximize2 } from 'lucide-react';

export default function App() {
  // Navigation & Mode state
  const [currentPage, setCurrentPage] = useState<NavigationPage>('overview');
  const [appMode, setAppMode] = useState<AppMode>('clinical');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  // Patient & Recording state
  const [currentPatientId, setCurrentPatientId] = useState<string>(MOCK_PATIENTS[0].id);
  const currentPatient = MOCK_PATIENTS.find((p) => p.id === currentPatientId) || MOCK_PATIENTS[0];
  const [selectedRecordingId, setSelectedRecordingId] = useState<string>(currentPatient.recordings[0].id);

  // Synchronized Selection State
  const [selectedElectrodeId, setSelectedElectrodeId] = useState<string | null>('T3');
  const [selectedRegionId, setSelectedRegionId] = useState<string | null>('left_temporal');
  const [preictalSeverity, setPreictalSeverity] = useState<number>(0.73);

  // Prediction data
  const [prediction, setPrediction] = useState<Prediction | null>(null);

  // Update recording when patient changes
  useEffect(() => {
    setSelectedRecordingId(currentPatient.recordings[0].id);
  }, [currentPatientId]);

  // Fetch prediction when patient/recording changes
  useEffect(() => {
    fetchPrediction(currentPatientId, selectedRecordingId).then((pred) => {
      setPrediction(pred);
    });
  }, [currentPatientId, selectedRecordingId]);

  // Synchronize electrode and regional selections
  const handleSelectElectrode = (electrodeId: string | null) => {
    setSelectedElectrodeId(electrodeId);
    if (electrodeId) {
      const elec = ELECTRODES_10_20.find((e) => e.id === electrodeId);
      if (elec) {
        setSelectedRegionId(elec.regionId);
      }
    }
  };

  const handleSelectRegion = (regionId: string | null) => {
    setSelectedRegionId(regionId);
    if (regionId) {
      const reg = BRAIN_REGIONS.find((r) => r.id === regionId);
      if (reg && reg.associatedChannels.length > 0) {
        setSelectedElectrodeId(reg.associatedChannels[0]);
      }
    }
  };

  const handleSelectHistoryEvent = (event: PatientHistoryEvent) => {
    setSelectedRecordingId(event.recordingId);
    if (event.associatedChannels.length > 0) {
      setSelectedElectrodeId(event.associatedChannels[0]);
    }
    setCurrentPage('overview');
  };

  if (!prediction) {
    return (
      <div className="h-screen w-screen bg-[#0a0e17] flex items-center justify-center text-slate-300 font-mono text-sm">
        <div className="flex items-center gap-3">
          <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <span>Initializing NeuroPulse Signal Processing Engine...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#070a12] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Bar Header */}
      <TopBar
        currentPatient={currentPatient}
        onSelectPatient={setCurrentPatientId}
        selectedRecordingId={selectedRecordingId}
        onSelectRecording={setSelectedRecordingId}
        appMode={appMode}
        onSelectAppMode={setAppMode}
      />

      {/* Body Area with Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          currentPage={currentPage}
          onSelectPage={setCurrentPage}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />

        {/* Main Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-7 space-y-6">
          {/* PATIENT MODE OVERRIDE */}
          {appMode === 'patient' ? (
            <PatientModeView
              prediction={prediction}
              onSwitchToClinical={() => setAppMode('clinical')}
            />
          ) : (
            <>
              {/* 1. OVERVIEW HERO PAGE (Composition per prompt Section 32) */}
              {currentPage === 'overview' && (
                <div className="space-y-6 max-w-[1700px] mx-auto">
                  {/* TOP ROW: Primary Cards (Brain State, Seizure Risk ML Score 73%, Prediction Window 10-30 min) */}
                  <TopOverviewCards
                    prediction={prediction}
                    brainStateLabel="Elevated pre-seizure activity"
                    signalQuality={94}
                  />

                  {/* MIDDLE ROW: 3D Brain (Hero Visual) + Timeline + Risk Gauge */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* 3D Brain Visualization Hero Canvas (7 cols on large screens) */}
                    <div className="lg:col-span-7 flex flex-col">
                      <BrainCanvas
                        regions={BRAIN_REGIONS}
                        electrodes={ELECTRODES_10_20}
                        selectedElectrodeId={selectedElectrodeId}
                        onSelectElectrode={handleSelectElectrode}
                        selectedRegionId={selectedRegionId}
                        onSelectRegion={handleSelectRegion}
                        preictalSeverity={preictalSeverity}
                        className="flex-1 min-h-[460px]"
                      />
                    </div>

                    {/* Timeline and Risk Gauge Side Stack (5 cols) */}
                    <div className="lg:col-span-5 flex flex-col gap-6">
                      <PredictionTimeline
                        prediction={prediction}
                        className="flex-1"
                      />
                      <RiskGauge prediction={prediction} />
                    </div>
                  </div>

                  {/* BOTTOM ROW: Multi-Channel EEG + Spectrogram + Frequency Bands + Explainability */}
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                    {/* Multi-channel EEG Viewer & Spectrogram (8 cols on XL) */}
                    <div className="xl:col-span-8 space-y-6">
                      <EEGViewer
                        selectedChannelId={selectedElectrodeId}
                        onSelectChannel={handleSelectElectrode}
                        preictalSeverity={preictalSeverity}
                      />

                      <SpectrogramViewer
                        selectedChannelId={selectedElectrodeId || 'T3'}
                        onSelectChannel={handleSelectElectrode}
                        preictalSeverity={preictalSeverity}
                      />
                    </div>

                    {/* Right Inspector Column: Why This Prediction? + Frequency Bands + Electrode/Region Details (4 cols on XL) */}
                    <div className="xl:col-span-4 space-y-6">
                      <WhyPredictionPanel
                        features={FEATURE_CONTRIBUTIONS}
                        selectedChannelId={selectedElectrodeId || 'T3'}
                      />

                      <FrequencyBandPanel
                        selectedChannelId={selectedElectrodeId || 'T3'}
                        preictalSeverity={preictalSeverity}
                      />

                      <ElectrodeInspector
                        selectedElectrodeId={selectedElectrodeId}
                        onSelectElectrode={handleSelectElectrode}
                        onSelectAssociatedRegion={handleSelectRegion}
                      />

                      {appMode === 'research' && (
                        <RegionalActivityList
                          selectedRegionId={selectedRegionId}
                          onSelectRegion={handleSelectRegion}
                          onSelectElectrode={handleSelectElectrode}
                        />
                      )}
                    </div>
                  </div>

                  {/* Research Mode Expansion: Connectivity Graph */}
                  {appMode === 'research' && (
                    <div className="pt-2">
                      <ConnectivityGraph
                        selectedChannelId={selectedElectrodeId}
                        onSelectChannel={handleSelectElectrode}
                      />
                    </div>
                  )}
                </div>
              )}

              {/* 2. DEDICATED 3D BRAIN STUDIO PAGE */}
              {currentPage === 'brain' && (
                <div className="space-y-6 max-w-[1700px] mx-auto">
                  <BrainActivityStudio
                    selectedElectrodeId={selectedElectrodeId}
                    onSelectElectrode={handleSelectElectrode}
                    selectedRegionId={selectedRegionId}
                    onSelectRegion={handleSelectRegion}
                    preictalSeverity={preictalSeverity}
                    onNavigateToEEG={(channelId) => {
                      setSelectedElectrodeId(channelId);
                      setCurrentPage('eeg');
                    }}
                    className="w-full"
                  />

                  {/* Secondary Regional Activity & Electrode Detail Panels */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-6">
                      <ElectrodeInspector
                        selectedElectrodeId={selectedElectrodeId}
                        onSelectElectrode={handleSelectElectrode}
                        onSelectAssociatedRegion={handleSelectRegion}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <RegionalActivityList
                        selectedRegionId={selectedRegionId}
                        onSelectRegion={handleSelectRegion}
                        onSelectElectrode={handleSelectElectrode}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 3. DEDICATED EEG & SPECTROGRAM STUDIO */}
              {currentPage === 'eeg' && (
                <div className="space-y-6 max-w-[1600px] mx-auto">
                  <EEGViewer
                    selectedChannelId={selectedElectrodeId}
                    onSelectChannel={handleSelectElectrode}
                    preictalSeverity={preictalSeverity}
                  />

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-8">
                      <SpectrogramViewer
                        selectedChannelId={selectedElectrodeId || 'T3'}
                        onSelectChannel={handleSelectElectrode}
                        preictalSeverity={preictalSeverity}
                      />
                    </div>
                    <div className="lg:col-span-4">
                      <FrequencyBandPanel
                        selectedChannelId={selectedElectrodeId || 'T3'}
                        preictalSeverity={preictalSeverity}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 4. DEDICATED EXPLAINABILITY (SHAP) STUDIO */}
              {currentPage === 'explainability' && (
                <div className="space-y-6 max-w-[1500px] mx-auto">
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-6 space-y-6">
                      <WhyPredictionPanel
                        features={FEATURE_CONTRIBUTIONS}
                        selectedChannelId={selectedElectrodeId || 'T3'}
                      />
                      <RiskGauge prediction={prediction} />
                    </div>

                    <div className="lg:col-span-6 space-y-6">
                      <PredictionTimeline prediction={prediction} />
                      <ElectrodeInspector
                        selectedElectrodeId={selectedElectrodeId}
                        onSelectElectrode={handleSelectElectrode}
                        onSelectAssociatedRegion={handleSelectRegion}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 5. DEDICATED CONNECTIVITY GRAPH PAGE */}
              {currentPage === 'connectivity' && (
                <div className="space-y-6 max-w-[1400px] mx-auto">
                  <ConnectivityGraph
                    selectedChannelId={selectedElectrodeId}
                    onSelectChannel={handleSelectElectrode}
                  />
                  <FrequencyBandPanel
                    selectedChannelId={selectedElectrodeId || 'T3'}
                    preictalSeverity={preictalSeverity}
                  />
                </div>
              )}

              {/* 6. MODEL LAB PAGE */}
              {currentPage === 'models' && <ModelLabView />}

              {/* 7. PATIENT HISTORY PAGE */}
              {currentPage === 'history' && (
                <PatientHistoryView onSelectEvent={handleSelectHistoryEvent} />
              )}

              {/* 8. REPORTS PAGE */}
              {currentPage === 'reports' && (
                <ReportsView
                  patientId={currentPatientId}
                  recordingId={selectedRecordingId}
                />
              )}

              {/* 9. DOCUMENTATION & ETHICS PAGE */}
              {currentPage === 'docs' && <DocsView />}
            </>
          )}
        </main>
      </div>

      {/* Mandatory Persistent Academic Prototype Disclaimer Notice */}
      <footer className="h-10 border-t border-slate-800 bg-[#080c14] px-4 flex items-center justify-between text-[11px] font-mono text-slate-400 z-20">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="text-slate-300">
            NeuroPulse is an academic research prototype and is not a clinically validated medical device.
          </span>
        </div>

        <div className="hidden sm:flex items-center gap-4 text-slate-500">
          <span>Signal: CHB-MIT Scalp EEG</span>
          <span>Sampling: 256 Hz</span>
          <span className="text-cyan-400">Model: XGBoost-Wavelet v1.4</span>
        </div>
      </footer>
    </div>
  );
}
